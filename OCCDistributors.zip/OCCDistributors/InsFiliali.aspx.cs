﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class InsFiliali : System.Web.UI.Page
    {
        private static string SIEMENS_GID = "";
        private Utilities ut = new Utilities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SIEMENS_GID = (string)Session["SIEMENS_GID"];
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            if (Controllo())
            {
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    Filiali filiale = new Filiali();
                    filiale.Codice = NomeFiliale.Text;
                    context.Filiali.Add(filiale);
                    context.SaveChanges();

                    ut.InsLog(SIEMENS_GID, "Filiali", 0, "INFO", "Inserita filiale: " + filiale.Codice);

                    Response.Redirect("MainFiliali.aspx", false);
                }
            }
        }
        private bool Controllo()
        {
            string strControllo = "";
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                strControllo = "<font color=red><ul>";
                var filiale = context.Filiali.FirstOrDefault(F => F.Codice == NomeFiliale.Text);
                if (filiale != null)
                {
                    strControllo = strControllo + "<li> Nome Filiale già esistente in archivio! " + "</li>";
                }
                strControllo = strControllo + "</ul></font>";
            }
            if (strControllo == "<font color=red><ul></ul></font>") // nessun impedimento
                return true;
            else
            {
                ErrorMessage.Text = strControllo;
                return false;
            }
        }
    }
}