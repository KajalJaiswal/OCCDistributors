﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class InsRivenditori : System.Web.UI.Page
    {
        private static string SIEMENS_GID = "";
        private Utilities ut = new Utilities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SIEMENS_GID = (string)Session["SIEMENS_GID"];
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    Codice_MacroArea.DataSource = context.GetMacroaree(SIEMENS_GID).ToList();
                    Codice_MacroArea.DataBind();
                    GVAssociaMacroArea.DataSource = (from C in context.MacroArea select new { C.Codice }).ToList();
                    GVAssociaMacroArea.DataBind();
                }
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            if (Controllo())
            {
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    Rivenditori rivenditore = new Rivenditori();
                    rivenditore.KN = KN.Text;
                    rivenditore.Ragione_Sociale = RagioneSociale.Text;
                    rivenditore.PartitaIva = PartitaIva.Text;
                    rivenditore.flg_Ricarica = Convert.ToBoolean(Ricarica.Checked);
                    rivenditore.flg_Principale = Convert.ToBoolean(Principale.Checked);
                    rivenditore.Codice_MacroArea = Codice_MacroArea.SelectedValue;
                    context.Rivenditori.Add(rivenditore);
                    context.SaveChanges();

                    ut.InsLog(SIEMENS_GID, "Rivenditori", 0, "INFO", "Inserito rivenditore: " + rivenditore.Ragione_Sociale);

                    foreach (GridViewRow GVAssociaMacroAreaRow in GVAssociaMacroArea.Rows)
                    {
                        string strMacroArea = GVAssociaMacroAreaRow.Cells[0].Text;
                        CheckBox chkMacroArea = (CheckBox)GVAssociaMacroAreaRow.FindControl("chkMacroArea");
                        if (chkMacroArea.Checked == true)
                        {
                            RivenditoriMacroarea rivenditoreMacroarea = new RivenditoriMacroarea();
                            rivenditoreMacroarea.KN = KN.Text;
                            rivenditoreMacroarea.Codice_MacroArea = strMacroArea;
                            context.RivenditoriMacroarea.Add(rivenditoreMacroarea);
                            context.SaveChanges();
                            ut.InsLog(SIEMENS_GID, "Rivenditori", 0, "INFO", "Inserito rivenditore per macro area: " + strMacroArea + "|" + rivenditore.Ragione_Sociale);
                        }
                    }
                    Session["idUltimoRivenditoreInserito"] = rivenditore.Ragione_Sociale;
                    Response.Redirect("MainRivenditori.aspx", false);
                }
            }
        }
        private bool Controllo()
        {
            string strControllo = "";
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                strControllo = "<font color=red><ul>";
                var rivenditore = context.Rivenditori.FirstOrDefault(R => R.KN == KN.Text);
                if (rivenditore != null)
                {
                    strControllo = strControllo + "<li> KN già assegnato a: " + rivenditore.Ragione_Sociale + "</li>";
                }
                // Controllo inutile in inserimento
                //foreach (GridViewRow GVAssociaMacroAreaRow in GVAssociaMacroArea.Rows)
                //{
                //    string strMacroArea = GVAssociaMacroAreaRow.Cells[0].Text;

                //    var rivenditoreMacroarea = context.RivenditoriMacroarea.FirstOrDefault(RM => RM.Codice_MacroArea == strMacroArea && RM.KN == KN.Text);
                //    if (rivenditoreMacroarea != null)
                //        strControllo = strControllo + "<li> KN inserito come rivenditore per macroarea: " + rivenditoreMacroarea.Codice_MacroArea + "</li>";
                //}
                if (Principale.Checked == true)
                {
                    // Controllo stessa partita iva se esiste principale
                    var chkPrincipale = context.Rivenditori.FirstOrDefault(R => R.PartitaIva == PartitaIva.Text && R.flg_Principale == true);
                    if (chkPrincipale != null)
                        strControllo = strControllo + "<li> Flag Principale già assegnato al KN: " + chkPrincipale.KN + " " + chkPrincipale.Ragione_Sociale + " con uguale partita Iva: " + chkPrincipale.PartitaIva + "</li>";
                }
                strControllo = strControllo + "</ul></font>";
            }
            if (strControllo == "<font color=red><ul></ul></font>") // nessun impedimento
                return true;
            else
            {
                ErrorMessage.Text = strControllo;
                return false;
            }
        }
    }
}