﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OCCDist
{
    public partial class InsUtenti : System.Web.UI.Page
    {
        private static string SIEMENS_GID = "";
        private Utilities ut = new Utilities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SIEMENS_GID = (string)Session["SIEMENS_GID"];

                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    GVAssociaUtente.DataSource = context.spGetMacroAree(SIEMENS_GID).ToList();
                    GVAssociaUtente.DataBind();
                }
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            if (Controllo())
            {
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    Utenti utente = new Utenti();
                    utente.GID = GID.Text;
                    utente.Cognome = Cognome.Text;
                    utente.Nome = Nome.Text;
                    utente.email = Email.Text;
                    // il Tipo non è più modificabile da interfaccia
                    //utente.Tipo = Tipo.Text;
                    utente.Tipo = null;
                    utente.note = Note.Text;
                    context.Utenti.Add(utente);
                    context.SaveChanges();

                    ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Inserito utente: " + utente.GID + "|" + utente.Cognome + "|" + utente.Nome);

                    foreach (GridViewRow GVAssociaUtenteRow in GVAssociaUtente.Rows)
                    {
                        string strMacroArea = GVAssociaUtenteRow.Cells[0].Text;
                        CheckBox chkSegreteria = (CheckBox)GVAssociaUtenteRow.FindControl("chkSegreteria");
                        if (chkSegreteria.Checked == true)
                        {
                            Segreterie segreteria = new Segreterie();
                            segreteria.GID = GID.Text;
                            segreteria.Codice_MacroArea = strMacroArea;
                            context.Segreterie.Add(segreteria);
                            context.SaveChanges();
                            ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Inserita segreteria: " + strMacroArea + "|" + utente.GID + "|" + utente.Cognome + "|" + utente.Nome);
                        }
                        CheckBox chkAgente = (CheckBox)GVAssociaUtenteRow.FindControl("chkAgente");
                        if (chkAgente.Checked == true)
                        {
                            Agenti agente = new Agenti();
                            agente.Gid = GID.Text;
                            agente.Codice_MacroArea = strMacroArea;
                            context.Agenti.Add(agente);
                            context.SaveChanges();
                            ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Inserito agente: " + strMacroArea + "|" + utente.GID + "|" + utente.Cognome + "|" + utente.Nome);
                        }
                        CheckBox chkResponsabile = (CheckBox)GVAssociaUtenteRow.FindControl("chkResponsabile");
                        if (chkResponsabile.Checked == true)
                        {
                            Responsabili responsabile = new Responsabili();
                            responsabile.GID = GID.Text;
                            responsabile.Codice_MacroArea = strMacroArea;
                            context.Responsabili.Add(responsabile);
                            context.SaveChanges();
                            ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Inserito responsabile: " + strMacroArea + "|" + utente.GID + "|" + utente.Cognome + "|" + utente.Nome);
                        }
                    }
                    //Session["idUltimoUtenteInserito"] = utente.Cognome + " " + utente.Nome;
                    Response.Redirect("MainUtenti.aspx", false);
                }
            }
        }
        private bool Controllo()
        {
            string strControllo = "";
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                strControllo = "<font color=red><ul>";
                var utente = context.Utenti.FirstOrDefault(U => U.GID == GID.Text);
                if (utente != null)
                {
                    strControllo = strControllo + "<li> GID già assegnato a: " + utente.Cognome + " " + utente.Nome + "</li>";
                }
                foreach (GridViewRow GVAssociaUtenteRow in GVAssociaUtente.Rows)
                {
                    string strMacroArea = GVAssociaUtenteRow.Cells[0].Text;

                    var segreteria = context.Segreterie.FirstOrDefault(S => S.Codice_MacroArea == strMacroArea && S.GID == GID.Text);
                    if (segreteria != null)
                        strControllo = strControllo + "<li> GID già inserito come segreteria per macroarea: " + segreteria.Codice_MacroArea + "</li>";

                    var agente = context.Agenti.FirstOrDefault(A => A.Codice_MacroArea == strMacroArea && A.Gid == GID.Text);
                    if (agente != null)
                        strControllo = strControllo + "<li> GID già inserito come agente per macroarea: " + agente.Codice_MacroArea + "</li>";

                    var responsabile = context.Responsabili.FirstOrDefault(R => R.Codice_MacroArea == strMacroArea && R.GID == GID.Text);
                    if (responsabile != null)
                        strControllo = strControllo + "<li> GID già inserito come responsabile per macroarea: " + responsabile.Codice_MacroArea + "</li>";
                }
                strControllo = strControllo + "</ul></font>";
            }
            if (strControllo == "<font color=red><ul></ul></font>") // nessun impedimento
                return true;
            else
            {
                ErrorMessage.Text = strControllo;
                return false;
            }
        }
    }
}