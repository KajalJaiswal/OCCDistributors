﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class MainClienti : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if ((string)Session["idUltimoClienteInserito"] != "" && Session["idUltimoClienteInserito"] != null)
                    idMessage.Text = "Ultimo cliente inserito: " + Convert.ToString(Session["idUltimoClienteInserito"]);
                ViewState["CliRagioneSociale"] = "";
                ViewState["MA"] = "";
                BindGrid();
            }
        }
        void BindGrid()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                string SIEMENS_GID = (string)Session["SIEMENS_GID"];

                var qryCanCreateNew = context.CanCreateNew(SIEMENS_GID).ToList();
                if (qryCanCreateNew.Count > 0)
                {
                    idHypCreaNuova.Visible = true; // Abilita il link per creare un nuovo cliente
                }

                var qrySelMainClienti = context.SelMainClienti(SIEMENS_GID,
                                                            (string)ViewState["CliRagioneSociale"],
                                                            (string)ViewState["MA"]);

                GVClienti.DataSource = qrySelMainClienti;
                GVClienti.DataBind();

                // Colonna MacroArea
                DropDownList ddlMA = (DropDownList)GVClienti.HeaderRow.FindControl("ddlMA");
                ddlMA.DataSource = context.GetMacroaree(SIEMENS_GID).ToList();
                ddlMA.DataBind();
                // inserisce un item blank per cancellare il filtro
                ddlMA.Items.Insert(0, new ListItem(String.Empty, String.Empty));

                RipristinaFiltri();
            }
        }

        protected void RipristinaFiltri()
        {
            if ((string)ViewState["CliRagioneSociale"] != "")
            {
                var CliRagioneSociale = (TextBox)GVClienti.HeaderRow.FindControl("txtRagioneSociale");
                if (CliRagioneSociale != null)
                    CliRagioneSociale.Text = ViewState["CliRagioneSociale"].ToString().ToUpper();
            }
            if ((string)ViewState["MA"] != "")
            {
                DropDownList ddlMA = (DropDownList)GVClienti.HeaderRow.FindControl("ddlMA");
                if (ddlMA != null)
                    ddlMA.SelectedValue = ViewState["MA"].ToString().ToUpper();
            }
        }
        protected void GVClienti_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                RipristinaFiltri();
            }
        }

        protected void GVClienti_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strTmp = ((LinkButton)GVClienti.SelectedRow.FindControl("lblID")).Text.ToString();
            strTmp = strTmp + @"&azione=Modifica";
            Response.Redirect("ModClienti.aspx?ID=" + strTmp, false);
        }
        protected void GVClienti_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVClienti.PageIndex = e.NewPageIndex;
            BindGrid();
        }
        protected void GVClienti_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["CliRagioneSociale"] = ((TextBox)GVClienti.HeaderRow.FindControl("txtRagioneSociale")).Text.ToString();
            ViewState["MA"] = ((DropDownList)GVClienti.HeaderRow.FindControl("ddlMA")).SelectedValue.ToString();
            BindGrid();
        }
        protected void btnDefault_Click(object sender, EventArgs e)
        {
            ViewState["CliRagioneSociale"] = ((TextBox)GVClienti.HeaderRow.FindControl("txtRagioneSociale")).Text.ToString();
            ViewState["MA"] = ((DropDownList)GVClienti.HeaderRow.FindControl("ddlMA")).SelectedValue.ToString();
            BindGrid();
        }
    }
}