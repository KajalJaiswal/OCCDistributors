﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class MainLogGestione : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ViewState["strSortExpression"] = "data";
                ViewState["UNominativo"] = "";
                ViewState["Data"] = "";
                BindGrid((string)ViewState["strSortExpression"]);
            }
        }
        void BindGrid(string SortColumn)
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                var qrySelMainLog = context.SelMainLogGestione((string)ViewState["Data"], (string)ViewState["UNominativo"], SortColumn).ToList();
                GVLog.DataSource = qrySelMainLog;
                GVLog.DataBind();
                RipristinaFiltri();
            }
        }
        protected void GVLog_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVLog.PageIndex = e.NewPageIndex;
            BindGrid((string)ViewState["strSortExpression"]);
        }
        protected void GVLog_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["strSortExpression"] = e.SortExpression;
            ViewState["Data"] = ((TextBox)GVLog.HeaderRow.FindControl("txtData")).Text.ToString();
            ViewState["UNominativo"] = ((TextBox)GVLog.HeaderRow.FindControl("txtUNominativo")).Text.ToString();
            BindGrid(e.SortExpression);
        }
        protected void RipristinaFiltri()
        {
            if ((string)ViewState["Data"] != "")
            {
                var txtData = (TextBox)GVLog.HeaderRow.FindControl("txtData");
                if (txtData != null)
                    txtData.Text = ViewState["Data"].ToString().ToUpper();
            }

            if ((string)ViewState["UNominativo"] != "")
            {
                var UNominativo = (TextBox)GVLog.HeaderRow.FindControl("txtUNominativo");
                if (UNominativo != null)
                    UNominativo.Text = ViewState["UNominativo"].ToString().ToUpper();
            }
        }
        protected void GVLog_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if (e.Row.RowType == DataControlRowType.Header)
                    RipristinaFiltri();
            }
        }
        protected void btnDefault_Click(object sender, EventArgs e)
        {
            ViewState["Data"] = ((TextBox)GVLog.HeaderRow.FindControl("txtData")).Text.ToString();
            ViewState["UNominativo"] = ((TextBox)GVLog.HeaderRow.FindControl("txtUNominativo")).Text.ToString();
            BindGrid("data");
        }
    }
}