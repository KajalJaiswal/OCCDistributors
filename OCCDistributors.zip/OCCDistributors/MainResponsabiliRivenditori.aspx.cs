﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class MainResponsabiliRivenditori : System.Web.UI.Page
    {
        private static string SIEMENS_GID = "";
        private static string GID = "";
        private Utilities ut = new Utilities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if ((Boolean)Session["AMMINISTRATORE"] == false)
                {
                    Response.Redirect("AccessDenied.aspx");
                }
                SIEMENS_GID = (string)Session["SIEMENS_GID"];
                GID = Request.QueryString["GID"];
                lblIntestazione.Text = "Associazione KN al GID:";
                idGID.Text = GID;
                BindGrid();
            }
        }
        void BindGrid()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                //var query = from R in context.Rivenditori
                //            orderby R.Ragione_Sociale
                //            select R;
                var qrySelMainResponsabiliRivenditori = context.SelMainResponsabiliRivenditori(GID).ToList();

                GVRivenditori.DataSource = qrySelMainResponsabiliRivenditori.ToList();
                GVRivenditori.DataBind();
            }
        }
        protected void btnAssociaRivenditori_Click(object sender, EventArgs e)
        {
            string strTmp = "";
            string KN = "";
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                try
                {
                    // Rimuove tutte le eventuali coppie presenti 
                    var qryDelResponsabiliRivenditori = context.DelResponsabiliRivenditori(idGID.Text);

                    // Inserisce quelli selezionati
                    foreach (GridViewRow GVSchedeRow in GVRivenditori.Rows)
                    {
                        CheckBox chkItem = (CheckBox)GVSchedeRow.FindControl("chkItem");
                        if (chkItem.Checked == true)
                        {
                            Label lblKN = (Label)GVSchedeRow.FindControl("lblKN");
                            KN = lblKN.Text;

                            Responsabili_Rivenditori responsabile_rivenditore = new Responsabili_Rivenditori();
                            responsabile_rivenditore.GID = idGID.Text;
                            responsabile_rivenditore.KN = KN;
                            context.Responsabili_Rivenditori.Add(responsabile_rivenditore);
                            context.SaveChanges();

                            ut.InsLog(SIEMENS_GID, "Utenti", 0, "INFO", "Inserito responsabile: " + idGID.Text + " per rivenditore:" + KN);
                        }
                    }
                    strTmp = idGID.Text;
                    strTmp = strTmp + @"&azione=Modifica";
                    Response.Redirect("ModUtenti.aspx?GID=" + strTmp, false);
                }
                catch (System.Exception ex)
                {
                    ut.InsLog(SIEMENS_GID, "Utenti", 0, "ERRORE", ex.ToString());
                    MessageBox(@"Si è verificato un errore durante l'assegnazione del responsabile: " + idGID.Text + " al rivenditore:" + KN +
                               ". La procedura di assegnazione è stata bloccata, consultare il log.", "Errore assegnazione responsabile/rivenditore");
                    Response.Redirect("ModUtenti.aspx?GID=" + strTmp, false);
                }
            }
        }
        private void MessageBox(string message, string title = "title")
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), title, "alert('" + message + "');", true);
        }
    }
}