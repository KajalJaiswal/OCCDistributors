﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class MainSchedeCopia : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if ((string)Session["idUltimaSchedaInserita"] != "") 
                    idMessage.Text = "Ultima scheda inserita id = " + Convert.ToString(Session["idUltimaSchedaInserita"]);
                ViewState["strSortExpression"] = "";
                ViewState["idScheda"] = "";
                ViewState["stato"] = "";
                ViewState["U1Nominativo"] = "";
                ViewState["U2Nominativo"] = "";
                ViewState["URNominativo"] = "";
                ViewState["RivRagioneSociale"] = "";
                ViewState["CliRagioneSociale"] = "";
                ViewState["Validita_Da"] = "";
                ViewState["Validita_A"] = "";
                BindGrid((string)ViewState["strSortExpression"]);
            }
        }
        void BindGrid(string SortColumn)
        {
            using (OCCEntities context = new OCCEntities())
            {
                string SIEMENS_GID = (string)Session["SIEMENS_GID"];

                string strMinAnnoFiscale = "";
                string strMaxAnnoFiscale = "";
                strMinAnnoFiscale = (string)ViewState["Validita_Da"];
                strMaxAnnoFiscale = (string)ViewState["Validita_A"];
                if ((string)ViewState["Validita_Da"] == "")
                {
                    var qryMinMaxAnnoFiscale = context.SelMinMaxAnnoFiscale().ToList();
                    strMinAnnoFiscale = qryMinMaxAnnoFiscale[0].Min_Periodo_Mese;
                    strMaxAnnoFiscale = qryMinMaxAnnoFiscale[0].Max_Periodo_Mese;
                }

                long lidScheda = 0;
                if ((string)ViewState["idScheda"] != "")
                    lidScheda = Convert.ToInt32((string)ViewState["idScheda"]);

                var qrySelMainSchede = context.SelMainSchede(SIEMENS_GID,
                                                            strMinAnnoFiscale,
                                                            strMaxAnnoFiscale,
                                                            lidScheda,
                                                            (string)ViewState["stato"],
                                                            (string)ViewState["U1Nominativo"],
                                                            (string)ViewState["U2Nominativo"],
                                                            (string)ViewState["URNominativo"],
                                                            (string)ViewState["RivRagioneSociale"],
                                                            (string)ViewState["CliRagioneSociale"],
                                                            SortColumn).ToList();
                GVSchede.DataSource = qrySelMainSchede;
                GVSchede.DataBind();

                if (GVSchede.Rows.Count > 0)
                {
                    // Colonna Stato
                    DropDownList ddlstatischede = (DropDownList)GVSchede.HeaderRow.FindControl("ddlStato");
                    ddlstatischede.DataSource = (from S in context.Stati_Schede
                                                 select S.Codice).ToList();
                    ddlstatischede.DataBind();

                    // inserisce un item blank per cancellare il filtro
                    ddlstatischede.Items.Insert(0, new ListItem(String.Empty, String.Empty));
                    ddlstatischede.SelectedValue = (string)ViewState["stato"];

                    // Colonne Validità
                    DropDownList ddlValidita_Da = (DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_Da");
                    DropDownList ddlValidita_A = (DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_A");

                    var queryPeriodi = (from P in context.AnnoFiscale_Periodi
                                        select P.Periodo_Mese);

                    ddlValidita_Da.DataSource = queryPeriodi.ToList();
                    ddlValidita_Da.SelectedValue = strMinAnnoFiscale;
                    ddlValidita_Da.DataBind();
                    ddlValidita_A.DataSource = queryPeriodi.ToList();
                    ddlValidita_A.SelectedValue = strMaxAnnoFiscale;
                    ddlValidita_A.DataBind();
                }
            }
        }
        protected void GVSchede_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strTmp = ((LinkButton)GVSchede.SelectedRow.FindControl("lblid")).Text.ToString();
            strTmp = strTmp + @"&azione=Copia";
            Response.Redirect("ModSchede.aspx?idscheda=" + strTmp);
        }
        protected void GVSchede_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVSchede.PageIndex = e.NewPageIndex;
            BindGrid((string)ViewState["strSortExpression"]);
        }

        protected void GVSchede_Sorting(object sender, GridViewSortEventArgs e)
        {
            ViewState["strSortExpression"] = e.SortExpression;
            ViewState["idScheda"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtid")).Text.ToString();
            ViewState["stato"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlStato")).SelectedValue.ToString();
            ViewState["U1Nominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtU1Nominativo")).Text.ToString();
            ViewState["U2Nominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtU2Nominativo")).Text.ToString();
            ViewState["URNominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtURNominativo")).Text.ToString();
            ViewState["RivRagioneSociale"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtRivRagioneSociale")).Text.ToString();
            ViewState["CliRagioneSociale"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtCliRagioneSociale")).Text.ToString();
            ViewState["Validita_Da"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_Da")).SelectedValue.ToString();
            ViewState["Validita_A"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_A")).SelectedValue.ToString();
            BindGrid(e.SortExpression);
        }
        protected void GVSchede_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if ((string)ViewState["idScheda"] != "")
                {
                    var idScheda = (TextBox)GVSchede.HeaderRow.FindControl("txtid");
                    if (idScheda != null)
                        idScheda.Text = ViewState["idScheda"].ToString().ToUpper();
                }

                if ((string)ViewState["stato"] != "")
                {
                    DropDownList ddlStato = (DropDownList)GVSchede.HeaderRow.FindControl("ddlStato");
                    ddlStato.SelectedValue = ViewState["stato"].ToString().ToUpper();
                }

                if ((string)ViewState["U1Nominativo"] != "")
                {
                    var U1Nominativo = (TextBox)GVSchede.HeaderRow.FindControl("txtU1Nominativo");
                    if (U1Nominativo != null)
                        U1Nominativo.Text = ViewState["U1Nominativo"].ToString().ToUpper();
                }
                if ((string)ViewState["U2Nominativo"] != "")
                {
                    var U2Nominativo = (TextBox)GVSchede.HeaderRow.FindControl("txtU2Nominativo");
                    if (U2Nominativo != null)
                        U2Nominativo.Text = ViewState["U2Nominativo"].ToString().ToUpper();
                }
                if ((string)ViewState["URNominativo"] != "")
                {
                    var URNominativo = (TextBox)GVSchede.HeaderRow.FindControl("txtURNominativo");
                    if (URNominativo != null)
                        URNominativo.Text = ViewState["URNominativo"].ToString().ToUpper();
                }
                if ((string)ViewState["RivRagioneSociale"] != "")
                {
                    var RivNominativo = (TextBox)GVSchede.HeaderRow.FindControl("txtRivRagioneSociale");
                    if (RivNominativo != null)
                        RivNominativo.Text = ViewState["RivRagioneSociale"].ToString().ToUpper();
                }
                if ((string)ViewState["CliRagioneSociale"] != "")
                {
                    var CliNominativo = (TextBox)GVSchede.HeaderRow.FindControl("txtCliRagioneSociale");
                    if (CliNominativo != null)
                        CliNominativo.Text = ViewState["CliRagioneSociale"].ToString().ToUpper();
                }
            }
        }
        protected void btnDefault_Click(object sender, EventArgs e)
        {
            ViewState["idScheda"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtid")).Text.ToString();
            ViewState["stato"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlStato")).SelectedValue.ToString();
            ViewState["U1Nominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtU1Nominativo")).Text.ToString();
            ViewState["U2Nominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtU2Nominativo")).Text.ToString();
            ViewState["URNominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtURNominativo")).Text.ToString();
            ViewState["RivRagioneSociale"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtRivRagioneSociale")).Text.ToString();
            ViewState["CliRagioneSociale"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtCliRagioneSociale")).Text.ToString();
            ViewState["Validita_Da"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_Da")).SelectedValue.ToString();
            ViewState["Validita_A"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_A")).SelectedValue.ToString();
            BindGrid("id");
        }
    }
}