﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class MainUtenti : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if ((string)Session["idUltimoUtenteInserito"] != "" && Session["idUltimoUtenteInserito"] != null)
                    idMessage.Text = "Ultimo utente inserito: " + Convert.ToString(Session["idUltimoUtenteInserito"]);
                ViewState["UCognome"] = "";
                BindGrid();
            }
        }
        void BindGrid()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                string SIEMENS_GID = (string)Session["SIEMENS_GID"];

                var qryCanCreateNew = context.CanCreateNew(SIEMENS_GID).ToList();
                if (qryCanCreateNew.Count > 0)
                {
                    idHypCreaNuova.Visible = true; // Abilita il link per creare una nuova scheda
                }

                var qrySelMainUtenti = context.SelMainUtenti(SIEMENS_GID,
                                                            (string)ViewState["UCognome"]);

                GVUtenti.DataSource = qrySelMainUtenti;
                GVUtenti.DataBind();

                if ((string)ViewState["UCognome"] != "")
                {
                    var UNominativo = (TextBox)GVUtenti.HeaderRow.FindControl("txtUCognome");
                    if (UNominativo != null)
                        UNominativo.Text = ViewState["UCognome"].ToString().ToUpper();
                }
            }
        }
        protected void GVUtenti_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strTmp = ((LinkButton)GVUtenti.SelectedRow.FindControl("lbGid")).Text.ToString();
            strTmp = strTmp + @"&azione=Modifica";
            Response.Redirect("ModUtenti.aspx?GID=" + strTmp, false);
        }
        protected void GVUtenti_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVUtenti.PageIndex = e.NewPageIndex;
            BindGrid();
        }
        protected void GVUtenti_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["UCognome"] = ((TextBox)GVUtenti.HeaderRow.FindControl("txtUCognome")).Text.ToString();
            BindGrid();
        }
        protected void btnDefault_Click(object sender, EventArgs e)
        {
            ViewState["UCognome"] = ((TextBox)GVUtenti.HeaderRow.FindControl("txtUCognome")).Text.ToString();
            BindGrid();
        }
        protected void GVUtenti_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if ((string)ViewState["UCognome"] != "")
                {
                    var UNominativo = (TextBox)GVUtenti.HeaderRow.FindControl("txtUCognome");
                    if (UNominativo != null)
                        UNominativo.Text = ViewState["UCognome"].ToString().ToUpper();
                }
            }
        }
    }
}