﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


namespace OCCDist
{
    public partial class ModSchede : System.Web.UI.Page
    {
        private string tmpRaggruppamento = "";
        private static string SIEMENS_GID = "";
        private Utilities ut = new Utilities();
        private static long lidSchedaErrore;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                idNumScheda.Text = Request.QueryString["idscheda"];
                SIEMENS_GID = (string)Session["SIEMENS_GID"];
                
                if (!ut.GidCanReadScheda(SIEMENS_GID, idNumScheda.Text))
                    Response.Redirect("MainSchede.aspx", false);

                if (!ut.GidCanWriteScheda(SIEMENS_GID, idNumScheda.Text))
                    DisabilitaFunzioni();


                lblAzione.Text = "Scheda n.ro :";
                if (Request.QueryString["azione"] == "Modifica")
                {
                    lblHeaderAzione.Text = "Schede - Modifica";
                }
                BindData();
            }
            if (GVDettaglio.Rows.Count > 0)
            {
                if (!chkRicRivenditore.Checked) // Rivenditore con flg ricarica = false
                {
                    GVDettaglio.HeaderRow.Cells[8].Text = ""; // il ciclo foreach che segue non comtempla l'header       
                }
                foreach (GridViewRow GVDettaglioRow in GVDettaglio.Rows)
                {
                    HiddenField hidSC_Finale = (HiddenField)GVDettaglioRow.FindControl("hidSC_Finale");
                    if (!string.IsNullOrEmpty(hidSC_Finale.Value))
                    {
                        Label lblSC_Finale = (Label)GVDettaglioRow.FindControl("lblSC_Finale");
                        lblSC_Finale.Text = hidSC_Finale.Value;
                    }
                    if (!chkRicRivenditore.Checked) // Rivenditore con flg ricarica = false
                    {
                        GVDettaglioRow.Cells[8].Text = ""; //  colonna "Ric."
                    }
                }
            }
        }

        void AbilitaBottoni()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                long lidscheda = Convert.ToInt32(idNumScheda.Text);
                var qryAbilitaBottoni = context.AbilitaBottoniMod(SIEMENS_GID, lidscheda);
                foreach (var item in qryAbilitaBottoni)
                {
                    switch (item)
                    {
                        case "SalvaInBozza":
                            btnSalvaInBozza.Visible = true;
                            break;
                        case "InviaPerApprovazione":
                            btnInviaPerApprovazione.Visible = true;
                            break;
                        case "Approva":
                            btnApprova.Visible = true;
                            break;
                        case "Rifiuta":
                            btnRifiuta.Visible = true;
                            break;
                        case "Copia":
                            btnCopia.Visible = true;
                            break;
                        case "Rimuovi":
                            // Solo se in bozza
                            if (lblStato.Text == "Bozza") btnRimuovi.Visible = true;
                            break;
                    }
                }
            }
        }
        void DisabilitaFunzioni()
        {
            // Intestazione
            ddlMacroArea.Enabled = false;
            txtValidita_Da.Enabled = false;
            txtValidita_A.Enabled = false;
            btnSearchModello.Enabled = false;
            btnSearchAgente_1.Enabled = false;
            btnSearchAgente_2.Enabled = false;
            btnSearchResponsabili.Enabled = false;
            btnSearchRivenditori.Enabled = false;
            btnSearchFiliali.Enabled = false;
            lblFiliale.Enabled = false;
            txtCodice_Cliente.Enabled = false;
            txtResponsabile_Fil_Riv.Enabled = false;
            btnSearchClienti.Enabled = false;
            txtRappresentante_Riv.Enabled = false;
            //txtFirma_Resp_Fil_Riv.Enabled = false;
            
            btnSalvaInBozza.Enabled = false;
            btnInviaPerApprovazione.Enabled = false;
            btnApprova.Enabled = false;
            btnRifiuta.Enabled = false;
            btnRimuovi.Enabled = false;

            // Prezzi Netti
            btnImportInGrid.Enabled = false;
            btnExportFromGrid.Enabled = false;
            //btnDelGrid.Enabled = false;
            btnCaricaDettaglioDaTesto.Enabled = false;
            btnImportInDettaglio.Enabled = false;
        }
        void BindData()
        {
            CaricaIntestazione();
            if (Request.QueryString["azione"] == "Modifica")
                AbilitaBottoni();
            CaricaPrezziNetti();
            CaricaDettaglio();

        }
        void CaricaIntestazione()
        {
            //int idIntestazione = Convert.ToInt32((Session["idScheda"]));
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {

                long idscheda = Convert.ToInt32(idNumScheda.Text);

                ddlMacroArea.DataValueField = "Codice_MacroArea";
                ddlMacroArea.DataTextField = "Codice_MacroArea";
                ddlMacroArea.DataSource = context.CanCreateNew(SIEMENS_GID).ToList();
                ddlMacroArea.DataBind();

                var intestazione = context.Schede_Intestazione.FirstOrDefault(S => S.id == idscheda);

                ddlMacroArea.SelectedValue = intestazione.Codice_MacroArea;

                id_modello.Text = intestazione.id_modello.ToString();

                var modello = (from M in context.Modelli_Intestazione
                               where M.id == intestazione.id_modello
                               select new { M.Descrizione }).FirstOrDefault();

                lbl_Descr_Modello.Text = modello.Descrizione;

                lblMCRivenditore.Text = intestazione.Codice_MacroArea;
                lblGid_Agente_1.Text = intestazione.Agente1_Gid;

                var agente1 = (from A in context.Agenti
                               join U in context.Utenti on A.Gid equals U.GID
                               where A.Codice_MacroArea == intestazione.Codice_MacroArea && A.Gid == intestazione.Agente1_Gid
                               select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome }).FirstOrDefault();

                lblAgente1.Text = agente1.Cognome + " " + agente1.Nome;
                lblGid_Agente_2.Text = intestazione.Agente2_Gid;

                var agente2 = (from A in context.Agenti
                               join U in context.Utenti on A.Gid equals U.GID
                               where A.Codice_MacroArea == intestazione.Codice_MacroArea && A.Gid == intestazione.Agente2_Gid
                               select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome }).FirstOrDefault();


                if (agente2 != null)
                {
                    lblAgente2.Text = agente2.Cognome + " " + agente2.Nome;
                }

                var responsabile = (from R in context.Responsabili
                                    join U in context.Utenti on R.GID equals U.GID
                                    where R.Codice_MacroArea == intestazione.Codice_MacroArea && R.GID == intestazione.Responsabile_Gid
                                    select new { R.Codice_MacroArea, R.GID, U.Cognome, U.Nome }).FirstOrDefault();

                lblResponsabile.Text = responsabile.Cognome + " " + responsabile.Nome;
                lblGid_Responsabile.Text = intestazione.Responsabile_Gid;
                txtValidita_Da.Text = intestazione.Validita_Da_Mese;
                txtValidita_A.Text = intestazione.Validita_A_Mese;

                var cliente = context.Clienti.FirstOrDefault(C => C.id == intestazione.Cliente);

                lblRagioneSociale.Text = cliente.Ragione_Sociale;
                lblP_Iva.Text = cliente.P_Iva;
                lblComune.Text = cliente.Comune;
                lblCAP.Text = cliente.CAP;
                lblProvincia.Text = cliente.Provincia;
                id_Cliente.Text = intestazione.Cliente.ToString();

                //var rivenditore = context.Rivenditori.FirstOrDefault(R => R.Codice_MacroArea == intestazione.Codice_MacroArea && R.KN == intestazione.Rivenditore_KN);
                var rivenditore = (from RM in context.RivenditoriMacroarea
                                    join R in context.Rivenditori on RM.KN equals R.KN
                                    where RM.Codice_MacroArea == intestazione.Codice_MacroArea && RM.KN == intestazione.Rivenditore_KN
                                    select new { R.Ragione_Sociale, R.flg_Ricarica}).FirstOrDefault();

                lblRivenditore.Text = rivenditore.Ragione_Sociale;
                lblKNRivenditore.Text = intestazione.Rivenditore_KN;
                chkRicRivenditore.Checked = Convert.ToBoolean(rivenditore.flg_Ricarica);

                lblFiliale.Text = intestazione.Filiale;

                txtCodice_Cliente.Text = intestazione.Codice_Cliente;
                txtRappresentante_Riv.Text = intestazione.Rappresentante_Riv;
                txtResponsabile_Fil_Riv.Text = intestazione.Responsabile_Fil_Riv;
                //txtFirma_Resp_Fil_Riv.Text = intestazione.Firma_Resp_Fil_Riv;

                //ddlStatoScheda.SelectedValue = intestazione.stato;
                var stato = (from S in context.Stati_Schede where S.Codice == intestazione.stato select new { S.Descrizione }).FirstOrDefault();
                lblStato.Text = stato.Descrizione;

                idCreatail.Text = string.Format("{0:dd/MM/yyyy}", intestazione.Creata_il);
                idModificatail.Text = string.Format("{0:dd/MM/yyyy}", intestazione.Modificata_il);
                idInviatail.Text = string.Format("{0:dd/MM/yyyy}", intestazione.Inviata_il);
                idApprovatail.Text = string.Format("{0:dd/MM/yyyy}", intestazione.Approvata_il);
            }
        }
        protected void btnVisualizzaDettaglio_Click(object sender, EventArgs e)
        {
                if (pnlDettaglio.Visible == false)
                {
                    pnlDettaglio.Visible = true;
                }
                else
                {
                    pnlDettaglio.Visible = false;
                }
        }
        protected void CaricaDettaglio()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                long lidIntestazione = Convert.ToInt32(idNumScheda.Text);

                var qrySelCaricaDettaglioDaScheda = context.SelCaricaDettaglioDaScheda(lidIntestazione).ToList();

                var DTDettaglio = new DataTable();
                DTDettaglio.Columns.AddRange(new DataColumn[]{ 
                new DataColumn("Descrizione_raggruppamento" , typeof(string)),
                new DataColumn("Codice_raggruppamento" , typeof(string)),
                new DataColumn("Descrizione_Spiridon" , typeof(string)),
                new DataColumn("Catalogo" , typeof(string)),
                new DataColumn("Descrizione_Prodotto" , typeof(string)),
                new DataColumn("Fam_SC" , typeof(string)),
                new DataColumn("Fam_SC_Riv" , typeof(string)),
                new DataColumn("Sconto" , typeof(string)),
                new DataColumn("Extra" , typeof(string)),
                new DataColumn("Ricarica" , typeof(string)),
            });

                foreach (var item in qrySelCaricaDettaglioDaScheda)
                {
                    DataRow dr = DTDettaglio.NewRow();
                    if (tmpRaggruppamento != item.CODICE_RAGGRUPPAMENTO)
                    {
                        DataRow drRag = DTDettaglio.NewRow();
                        drRag["Descrizione_raggruppamento"] = "";
                        drRag["Codice_raggruppamento"] = "";
                        drRag["Descrizione_Spiridon"] = item.DESCRIZIONE; //Descrizione Raggruppamento
                        drRag["Catalogo"] = "";
                        drRag["Descrizione_Prodotto"] = "Raggruppamento";
                        drRag["Fam_SC"] = item.CODICE_RAGGRUPPAMENTO;
                        drRag["Fam_SC_Riv"] = "";
                        drRag["Sconto"] = "";
                        drRag["Extra"] = "";
                        drRag["Ricarica"] = "";
                        DTDettaglio.Rows.Add(drRag);
                        tmpRaggruppamento = item.CODICE_RAGGRUPPAMENTO;
                    }
                    dr["Descrizione_raggruppamento"] = item.DESCRIZIONE;
                    dr["Codice_raggruppamento"] = item.CODICE_RAGGRUPPAMENTO;
                    dr["Descrizione_Spiridon"] = item.DESCRIZIONE_SPIRIDON;
                    dr["Catalogo"] = item.CATALOGO;
                    if (item.DESCRIZIONE_PRODOTTO.Length > 50)
                        dr["Descrizione_Prodotto"] = item.DESCRIZIONE_PRODOTTO.Substring(0, 50);
                    else
                        dr["Descrizione_Prodotto"] = item.DESCRIZIONE_PRODOTTO;
                    dr["Fam_SC"] = item.FAM_SC;
                    dr["Fam_SC_Riv"] = item.FAM_SC_RIV;
                    dr["Sconto"] = item.SCONTO;
                    dr["Extra"] = item.EXTRA;
                    dr["Ricarica"] = item.RICARICA;
                    DTDettaglio.Rows.Add(dr);
                }
                //ViewState["dtDettaglio"] = DTDettaglio;
                //GVDettaglio.DataSource = ViewState["dtDettaglio"] as DataTable;
                GVDettaglio.DataSource = DTDettaglio;
                GVDettaglio.DataBind();
            }

        }
        protected void ddlMacroArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Azzera tutti valori che dipendono dalla macro area
            // Agente 1
            lblAgente1.Text = "";
            lblGid_Agente_1.Text = "";
            // Agente 2
            lblAgente2.Text = "";
            lblGid_Agente_2.Text = "";
            // Responsabile
            lblResponsabile.Text = "";
            lblGid_Responsabile.Text = "";
            // Rivenditore
            lblRivenditore.Text = "";
            lblMCRivenditore.Text = "";
            lblKNRivenditore.Text = "";
            // Cliente
            id_Cliente.Text = "";
            lblRagioneSociale.Text = "";
            lblP_Iva.Text = "";
            lblComune.Text = "";
            lblCAP.Text = "";
            lblProvincia.Text = "";
        }

        protected void GVDettaglio_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
                if (!chkRicRivenditore.Checked) // Rivenditore con flg ricarica = false
                {
                    e.Row.Cells[8].Text = ""; // intestazione colonna "Ric."
                }
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                Label lblDescProd = (Label)e.Row.FindControl("lblIDescrizione_Prodotto");
                if (lblDescProd.Text == "Raggruppamento")
                {
                    Label lblIDescrizione_Spiridon = (Label)e.Row.FindControl("lblIDescrizione_Spiridon");
                    lblIDescrizione_Spiridon.BackColor = System.Drawing.Color.LightGray;
                    lblIDescrizione_Spiridon.ForeColor = System.Drawing.Color.Gray;
                    Label lblICatalogo = (Label)e.Row.FindControl("lblICatalogo");
                    lblICatalogo.BackColor = System.Drawing.Color.LightGray;
                    lblICatalogo.ForeColor = System.Drawing.Color.Gray;
                    lblDescProd.BackColor = System.Drawing.Color.LightGray;
                    lblDescProd.ForeColor = System.Drawing.Color.Gray;
                    Label lblFamSC = (Label)e.Row.FindControl("lblIFam_SC");
                    lblFamSC.BackColor = System.Drawing.Color.LightGray;
                    lblFamSC.ForeColor = System.Drawing.Color.Gray;
                    e.Row.Font.Bold = true;
                    e.Row.ForeColor = System.Drawing.Color.LightYellow;
                    e.Row.FindControl("lblIFam_SC_Riv").Visible = false;
                    e.Row.FindControl("txtSconto").Visible = false;
                    e.Row.FindControl("txtExtra").Visible = false;
                    e.Row.FindControl("lblSC_Finale").Visible = false;
                    e.Row.FindControl("txtRicarica").Visible = false;
                }
                else
                {
                    if (!chkRicRivenditore.Checked) // Rivenditore con flg ricarica = false
                    {
                        e.Row.Cells[8].Text = ""; //  colonna "Ric."
                    }
                    TextBox txtSconto = (TextBox)e.Row.FindControl("txtSconto");
                    TextBox txtExtra = (TextBox)e.Row.FindControl("txtExtra");
                    HiddenField hidSC_Finale = (HiddenField)e.Row.FindControl("hidSC_Finale");
                    Label lblSC_Finale = (Label)e.Row.FindControl("lblSC_Finale");
                    txtExtra.Attributes.Add("onblur", "CalcolaSconto('" + txtSconto.ClientID + "','" + txtExtra.ClientID + "','" + hidSC_Finale.ClientID + "','" + lblSC_Finale.ClientID + "')");
                    if (Convert.ToDecimal(txtSconto.Text) > 0)
                    {
                        //var ScontoFinale = parseInt(txtSconto.value) + ((1 - (parseInt(txtSconto.value) / 100)) * parseInt(txtExtra.value));
                        lblSC_Finale.Text = (Decimal.Round(Convert.ToDecimal(txtSconto.Text) + ((1 - (Convert.ToDecimal(txtSconto.Text) / 100)) * Convert.ToDecimal(txtExtra.Text)), 2)).ToString();
                        hidSC_Finale.Value = lblSC_Finale.Text;
                    }
                }
            }
        }
        // A G E N T E  1 -----------------------------------------------------
        protected void btnSearchAgente_1_Click(object sender, EventArgs e)
        {
            ViewState["A1Cognome"] = "";
            BindAgenti_1();
            ModalPopupAgenti_1.Show();
        }
        void BindAgenti_1()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                if ((string)ViewState["A1Cognome"] == "")
                {
                    var query = from A in context.Agenti
                                join U in context.Utenti on A.Gid equals U.GID
                                where A.Codice_MacroArea == ddlMacroArea.SelectedValue
                                orderby U.Cognome
                                select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome };
                    GVAgenti_1.DataSource = query.ToList();
                }
                else
                {
                    string strFilter = (string)ViewState["A1Cognome"];
                    var query = from A in context.Agenti
                                join U in context.Utenti on A.Gid equals U.GID
                                where A.Codice_MacroArea == ddlMacroArea.SelectedValue && U.Cognome.StartsWith(strFilter)
                                orderby U.Cognome
                                select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome };

                    GVAgenti_1.DataSource = query.ToList();
                }
                GVAgenti_1.DataBind();
            }
        }
        protected void GVAgenti_1_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblAgente1.Text = ((Label)GVAgenti_1.SelectedRow.FindControl("lblA1Cognome")).Text.ToString() + " " + GVAgenti_1.SelectedRow.Cells[2].Text;
            lblGid_Agente_1.Text = GVAgenti_1.SelectedRow.Cells[4].Text;
            GVAgenti_1.DataSource = null;
            GVAgenti_1.DataBind();
        }
        protected void GVAgenti_1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVAgenti_1.PageIndex = e.NewPageIndex;
            BindAgenti_1();
            ModalPopupAgenti_1.Show();
        }
        protected void GVAgenti_1_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["A1Cognome"] = ((TextBox)GVAgenti_1.HeaderRow.FindControl("txtA1Cognome")).Text.ToString();
            BindAgenti_1();
            ModalPopupAgenti_1.Show();
        }
        protected void txtA1Cognome_TextChanged(object sender, EventArgs e)
        {
            ViewState["A1Cognome"] = ((TextBox)GVAgenti_1.HeaderRow.FindControl("txtA1Cognome")).Text.ToString();
            BindAgenti_1(); // 
            ModalPopupAgenti_1.Show();
        }
        protected void GVAgenti_1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if ((string)ViewState["A1Cognome"] != "")
                {
                    var txtA1Cognome = (TextBox)GVAgenti_1.HeaderRow.FindControl("txtA1Cognome");
                    if (txtA1Cognome != null)
                        txtA1Cognome.Text = ViewState["A1Cognome"].ToString();
                }
            }
        }

        // A G E N T E  2 -----------------------------------------------------
        protected void btnSearchAgente_2_Click(object sender, EventArgs e)
        {
            lblAgente2.Text = "";
            lblGid_Agente_2.Text = "";
            ViewState["A2Cognome"] = "";
            BindAgenti_2();
            ModalPopupAgenti_2.Show();
        }
        void BindAgenti_2()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                if ((string)ViewState["A2Cognome"] == "")
                {
                    var query = from A in context.Agenti
                                join U in context.Utenti on A.Gid equals U.GID
                                where A.Codice_MacroArea == ddlMacroArea.SelectedValue
                                orderby U.Cognome
                                select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome };
                    GVAgenti_2.DataSource = query.ToList();
                }
                else
                {
                    string strFilter = (string)ViewState["A2Cognome"];
                    var query = from A in context.Agenti
                                join U in context.Utenti on A.Gid equals U.GID
                                where A.Codice_MacroArea == ddlMacroArea.SelectedValue && U.Cognome.StartsWith(strFilter)
                                orderby U.Cognome
                                select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome };

                    GVAgenti_2.DataSource = query.ToList();
                }
                GVAgenti_2.DataBind();
            }
        }
        protected void GVAgenti_2_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblAgente2.Text = ((Label)GVAgenti_2.SelectedRow.FindControl("lblA2Cognome")).Text.ToString() + " " + GVAgenti_2.SelectedRow.Cells[2].Text;
            lblGid_Agente_2.Text = GVAgenti_2.SelectedRow.Cells[4].Text;
            GVAgenti_2.DataSource = null;
            GVAgenti_2.DataBind();
        }
        protected void GVAgenti_2_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVAgenti_2.PageIndex = e.NewPageIndex;
            BindAgenti_2();
            ModalPopupAgenti_2.Show();
        }
        protected void GVAgenti_2_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["A2Cognome"] = ((TextBox)GVAgenti_2.HeaderRow.FindControl("txtA2Cognome")).Text.ToString();
            BindAgenti_2();
            ModalPopupAgenti_2.Show();
        }
        protected void txtA2Cognome_TextChanged(object sender, EventArgs e)
        {
            ViewState["A2Cognome"] = ((TextBox)GVAgenti_2.HeaderRow.FindControl("txtA2Cognome")).Text.ToString();
            BindAgenti_2(); // 
            ModalPopupAgenti_2.Show();
        }
        protected void GVAgenti_2_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if ((string)ViewState["A2Cognome"] != "")
                {
                    var txtA2Cognome = (TextBox)GVAgenti_2.HeaderRow.FindControl("txtA2Cognome");
                    if (txtA2Cognome != null)
                        txtA2Cognome.Text = ViewState["A2Cognome"].ToString();
                }
            }
        }

        // R E S P O N S A B I L I --------------------------------------------
        protected void btnSearchResponsabili_Click(object sender, EventArgs e)
        {
            ViewState["ARCognome"] = "";
            BindResponsabili();
            ModalPopupResponsabili.Show();
        }

        void BindResponsabili()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                if ((string)ViewState["ARCognome"] == "")
                {
                    var query = from A in context.Responsabili
                                join U in context.Utenti on A.GID equals U.GID
                                where A.Codice_MacroArea == ddlMacroArea.SelectedValue
                                orderby U.Cognome
                                select new { A.Codice_MacroArea, A.GID, U.Cognome, U.Nome };
                    GVResponsabili.DataSource = query.ToList();
                }
                else
                {
                    string strFilter = (string)ViewState["ARCognome"];
                    var query = from A in context.Responsabili
                                join U in context.Utenti on A.GID equals U.GID
                                where A.Codice_MacroArea == ddlMacroArea.SelectedValue && U.Cognome.StartsWith(strFilter)
                                orderby U.Cognome
                                select new { A.Codice_MacroArea, A.GID, U.Cognome, U.Nome };

                    GVResponsabili.DataSource = query.ToList();
                }
                GVResponsabili.DataBind();
            }
        }
        protected void GVResponsabili_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVResponsabili.PageIndex = e.NewPageIndex;
            BindResponsabili();
            ModalPopupResponsabili.Show();
        }
        protected void GVResponsabili_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblResponsabile.Text = ((Label)GVResponsabili.SelectedRow.FindControl("lblARCognome")).Text.ToString() + " " + GVResponsabili.SelectedRow.Cells[2].Text;
            lblGid_Responsabile.Text = GVResponsabili.SelectedRow.Cells[4].Text;
            GVResponsabili.DataSource = null;
            GVResponsabili.DataBind();
        }
        protected void GVResponsabili_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["ARCognome"] = ((TextBox)GVResponsabili.HeaderRow.FindControl("txtARCognome")).Text.ToString();
            BindResponsabili();
            ModalPopupResponsabili.Show();
        }
        protected void txtARCognome_TextChanged(object sender, EventArgs e)
        {
            ViewState["ARCognome"] = ((TextBox)GVResponsabili.HeaderRow.FindControl("txtARCognome")).Text.ToString();
            BindResponsabili();
            ModalPopupResponsabili.Show();
        }
        protected void GVResponsabili_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if ((string)ViewState["ARCognome"] != "")
                {
                    var txtARCognome = (TextBox)GVResponsabili.HeaderRow.FindControl("txtARCognome");
                    if (txtARCognome != null)
                        txtARCognome.Text = ViewState["ARCognome"].ToString();
                }
            }
        }

        // F I L I A L I ------------------------------------------------------
        protected void btnSearchFiliali_Click(object sender, EventArgs e)
        {
            ViewState["Filiale"] = "";
            BindFiliali();
            ModalPopupFiliali.Show();
        }
        void BindFiliali()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                if ((string)ViewState["Filiale"] == "")
                {
                    var query = from F in context.Filiali select F;
                    GVFiliali.DataSource = query.ToList();
                }
                else
                {
                    string strFilter = (string)ViewState["Filiale"];
                    var query = from F in context.Filiali
                                where F.Codice.StartsWith(strFilter)
                                orderby F.Codice
                                select F;

                    GVFiliali.DataSource = query.ToList();
                }
                GVFiliali.DataBind();
            }
        }
        protected void GVFiliali_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVFiliali.PageIndex = e.NewPageIndex;
            BindFiliali();
            ModalPopupFiliali.Show();
        }
        protected void GVFiliali_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblFiliale.Text = ((Label)GVFiliali.SelectedRow.FindControl("lblCodice")).Text.ToString();
            GVFiliali.DataSource = null;
            GVFiliali.DataBind();
        }
        protected void GVFiliali_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["Filiale"] = ((TextBox)GVFiliali.HeaderRow.FindControl("txtFiliale")).Text.ToString();
            BindFiliali();
            ModalPopupFiliali.Show();
        }
        protected void txtFiliale_TextChanged(object sender, EventArgs e)
        {
            ViewState["Filiale"] = ((TextBox)GVFiliali.HeaderRow.FindControl("txtFiliale")).Text.ToString();
            BindFiliali();
            ModalPopupFiliali.Show();
        }
        protected void GVFiliali_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if ((string)ViewState["Filiale"] != "")
                {
                    var txtFiliale = (TextBox)GVFiliali.HeaderRow.FindControl("txtFiliale");
                    if (txtFiliale != null)
                        txtFiliale.Text = ViewState["Filiale"].ToString();
                }
            }
        }

        // C L I E N T I ------------------------------------------------------
        protected void btnSearchClienti_Click(object sender, EventArgs e)
        {
            ViewState["Ragione_Sociale"] = "";
            BindClienti();
            ModalPopupClienti.Show();
        }
        void BindClienti()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                if (context.Clienti.Count() > 0)
                {
                    if ((string)ViewState["Ragione_Sociale"] == "")
                    {
                        GVClienti.DataSource = context.Clienti
                            .Where(C => C.Codice_MacroArea == ddlMacroArea.SelectedValue)
                            .OrderBy(C => C.Ragione_Sociale).ToList();
                    }
                    else
                    {
                        string strFilter = (string)ViewState["Ragione_Sociale"];
                        GVClienti.DataSource = context.Clienti
                            .Where(C => C.Codice_MacroArea == ddlMacroArea.SelectedValue && C.Ragione_Sociale.StartsWith(strFilter))
                            .OrderBy(C => C.Ragione_Sociale).ToList();
                    }
                    GVClienti.DataBind();
                }
            }
        }
        protected void GVClienti_SelectedIndexChanged(object sender, EventArgs e)
        {
            id_Cliente.Text = GVClienti.SelectedRow.Cells[1].Text;
            lblRagioneSociale.Text = ((Label)GVClienti.SelectedRow.FindControl("lblRagione_Sociale")).Text.ToString();
            //lblRagioneSociale.Text = GVClienti.SelectedRow.Cells[2].Text;
            lblP_Iva.Text = GVClienti.SelectedRow.Cells[3].Text;
            lblComune.Text = GVClienti.SelectedRow.Cells[4].Text;
            lblCAP.Text = GVClienti.SelectedRow.Cells[5].Text;
            lblProvincia.Text = GVClienti.SelectedRow.Cells[6].Text;
            GVClienti.DataSource = null;
            GVClienti.DataBind();
        }
        protected void GVClienti_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVClienti.PageIndex = e.NewPageIndex;
            BindClienti();
            ModalPopupClienti.Show();
        }
        protected void GVClienti_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["Ragione_Sociale"] = ((TextBox)GVClienti.HeaderRow.FindControl("txtRagione_Sociale")).Text.ToString();
            BindClienti();
            ModalPopupClienti.Show();
        }
        protected void txtRagione_Sociale_TextChanged(object sender, EventArgs e)
        {
            ViewState["Ragione_Sociale"] = ((TextBox)GVClienti.HeaderRow.FindControl("txtRagione_Sociale")).Text.ToString();
            BindClienti();
            ModalPopupClienti.Show();
        }
        protected void GVClienti_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if ((string)ViewState["Ragione_Sociale"] != "")
                {
                    var txtRagione_Sociale = (TextBox)GVClienti.HeaderRow.FindControl("txtRagione_Sociale");
                    if (txtRagione_Sociale != null)
                        txtRagione_Sociale.Text = ViewState["Ragione_Sociale"].ToString();
                }
            }
        }

        // R I V E N D I T O R I ----------------------------------------------
        protected void btnSearchRivenditori_Click(object sender, EventArgs e)
        {
            ViewState["Ragione_Sociale_Riv"] = "";
            BindRivenditori();
            ModalPopupRivenditori.Show();
        }
        void BindRivenditori()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                if (context.Rivenditori.Count() > 0)
                {
                    if ((string)ViewState["Ragione_Sociale_Riv"] == "")
                    {
                        //GVRivenditori.DataSource = context.Rivenditori
                        //    .Where(C => C.Codice_MacroArea == ddlMacroArea.SelectedValue)
                        //    .OrderBy(C => C.Ragione_Sociale).ToList();
                        var qryRivenditori = from RM in context.RivenditoriMacroarea
                                             join R in context.Rivenditori on RM.KN equals R.KN
                                             where RM.Codice_MacroArea == ddlMacroArea.SelectedValue
                                             orderby R.Ragione_Sociale
                                             select new { R.Ragione_Sociale, RM.KN, RM.Codice_MacroArea, R.flg_Ricarica };
                        GVRivenditori.DataSource = qryRivenditori.ToList();
                    }
                    else
                    {
                        string strFilter = (string)ViewState["Ragione_Sociale_Riv"];
                        //GVRivenditori.DataSource = context.Rivenditori
                        //    .Where(C => C.Codice_MacroArea == ddlMacroArea.SelectedValue && C.Ragione_Sociale.StartsWith(strFilter))
                        //    .OrderBy(C => C.Ragione_Sociale).ToList();
                        var qryRivenditori = from RM in context.RivenditoriMacroarea
                                             join R in context.Rivenditori on RM.KN equals R.KN
                                             where RM.Codice_MacroArea == ddlMacroArea.SelectedValue && R.Ragione_Sociale.StartsWith(strFilter)
                                             orderby R.Ragione_Sociale
                                             select new { R.Ragione_Sociale, RM.KN, RM.Codice_MacroArea, R.flg_Ricarica };
                        GVRivenditori.DataSource = qryRivenditori.ToList();
                    }
                    GVRivenditori.DataBind();
                }
            }
        }
        protected void GVRivenditori_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblRivenditore.Text = ((Label)GVRivenditori.SelectedRow.FindControl("lblRagione_Sociale_Riv")).Text.ToString();
            lblKNRivenditore.Text = GVRivenditori.SelectedRow.Cells[2].Text;
            lblMCRivenditore.Text = GVRivenditori.SelectedRow.Cells[3].Text;
            chkRicRivenditore.Checked = Convert.ToBoolean(GVRivenditori.SelectedRow.Cells[4].Text);
            GVRivenditori.DataSource = null;
            GVRivenditori.DataBind();
            //if (id_modello.Text != "")
            //{
            //    cfrRivenditore.Enabled = true;
            //    cfrModello.Enabled = true;
            //    CaricaDettaglio();
            //}

        }
        protected void GVRivenditori_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVRivenditori.PageIndex = e.NewPageIndex;
            BindRivenditori();
            ModalPopupRivenditori.Show();
        }
        protected void GVRivenditori_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["Ragione_Sociale_Riv"] = ((TextBox)GVRivenditori.HeaderRow.FindControl("txtRagione_Sociale_Riv")).Text.ToString();
            BindRivenditori();
            ModalPopupRivenditori.Show();
        }
        protected void txtRagione_Sociale_Riv_TextChanged(object sender, EventArgs e)
        {
            ViewState["Ragione_Sociale_Riv"] = ((TextBox)GVRivenditori.HeaderRow.FindControl("txtRagione_Sociale_Riv")).Text.ToString();
            BindRivenditori();
            ModalPopupRivenditori.Show();
        }
        protected void GVRivenditori_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if ((string)ViewState["Ragione_Sociale_Riv"] != "")
                {
                    var txtRagione_Sociale_Riv = (TextBox)GVRivenditori.HeaderRow.FindControl("txtRagione_Sociale_Riv");
                    if (txtRagione_Sociale_Riv != null)
                        txtRagione_Sociale_Riv.Text = ViewState["Ragione_Sociale_Riv"].ToString();
                }
            }
        }
        protected void CaricaPrezziNetti()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                long iNumScheda = Convert.ToInt32(idNumScheda.Text);

                var prezzi_netti = context.Prezzi_Netti
                    .Where(I => I.id_Intestazione == iNumScheda)
                    .OrderBy(I => I.Codice_Materiale).ToList();

                string strPrezziNetti="";
                foreach (Prezzi_Netti item in prezzi_netti)
                {
                    strPrezziNetti = strPrezziNetti + item.Codice_Materiale + '\t';
                    strPrezziNetti = strPrezziNetti + item.Prezzo_Netto + '\t';
                    strPrezziNetti = strPrezziNetti + item.Ricarica + '\n';
                }
                ViewState["PrezziNetti"] = strPrezziNetti;
                BindPrezziNetti();

                idBadgePrezziNetti.InnerText = (prezzi_netti.Count).ToString();
            }
        }
        protected void btnVisualizzaPrezziNetti_Click(object sender, EventArgs e)
        {
            ModalPopupPrezziNetti.Show();
        }
        protected void BindPrezziNetti()
        {
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[3] { new DataColumn("Codice_Materiale", typeof(string)),
                    new DataColumn("Prezzo_Netto", typeof(float)),
                    new DataColumn("Ricarica",typeof(float)) });

            string strPrezziNetti = (string)ViewState["PrezziNetti"];
            foreach (string row in strPrezziNetti.Split('\n'))
            {
                if (!string.IsNullOrEmpty(row))
                {
                    dt.Rows.Add();
                    int i = 0;
                    foreach (string cell in row.Split('\t'))
                    {
                        dt.Rows[dt.Rows.Count - 1][i] = cell;
                        i++;
                    }
                }
            }
            GVPrezziNetti.DataSource = dt;
            GVPrezziNetti.DataBind();

            idBadgePrezziNetti.InnerText = (dt.Rows.Count).ToString();

        }
        protected void GVPrezziNetti_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVPrezziNetti.PageIndex = e.NewPageIndex;
            BindPrezziNetti();
            ModalPopupPrezziNetti.Show();
        }

        protected void btnDelGrid_Click(object sender, EventArgs e)
        {
            ViewState["PrezziNetti"] = "";
            BindPrezziNetti();
            ModalPopupPrezziNetti.Show();
        }
        protected void btnExportFromGrid_Click(object sender, EventArgs e)
        {
            txtCopied.Text = (string)ViewState["PrezziNetti"];
            ModalPopupPrezziNetti.Show();
        }
        protected void btnImportInGrid_Click(object sender, EventArgs e)
        {
            ViewState["PrezziNetti"] = txtCopied.Text;
            BindPrezziNetti();
            txtCopied.Text = "";
            ModalPopupPrezziNetti.Show();
        }
        protected bool ControlloScheda()
        {
            string strErrorMessage = "";
            idErrorMessage.Text = "";
            //if (id_modello.Text == "")
            //{
            //    strErrorMessage = @"Identificativo Modello; ";
            //}
            if (lblGid_Agente_1.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Identificativo Agente 1; ";
            }
            if (lblGid_Responsabile.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Identificativo Responsabile; ";
            }
            if (txtValidita_Da.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Data Validità da; ";
            }
            if (txtValidita_A.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Data Validità A;";
            }
            if (id_Cliente.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Identificativo Cliente; ";
            }
            if (lblKNRivenditore.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Identificativo Rivenditore; ";
            }
            if (lblFiliale.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Identificativo Filiale; ";
            }

            if (strErrorMessage == "")
                return true;
            else
            {
                idErrorMessage.Text = "Risultano non inseriti i seguenti campi obbligatori: " + strErrorMessage;
                return false;
            }
        }
        protected bool ControlloDate()
        {
            if (Convert.ToInt32(txtValidita_A.Text) < Convert.ToInt32(txtValidita_Da.Text))
            {
                idErrorMessage.Text = @"Data fine validità minore di data inizio validità.";
                return false;
            }
            else
                return true;
        }
        protected bool ControlloIndicePerModifica()
        {
            // Controllo violazione indice univoco su Schede_Intestazione
            long lidIntestazione = Convert.ToInt32(idNumScheda.Text);
            idErrorMessage.Text = "";
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                long lid_Cliente = Convert.ToInt32(id_Cliente.Text);
                var query = (from S in context.Schede_Intestazione
                             where S.Validita_Da_Mese == txtValidita_Da.Text &&
                                   S.Validita_A_Mese == txtValidita_A.Text &&
                                   S.Codice_MacroArea == ddlMacroArea.SelectedValue &&
                                   S.Rivenditore_KN == lblKNRivenditore.Text &&
                                   S.Cliente == lid_Cliente &&
                                   S.id != lidIntestazione // escludo se stessa
                             select new { S.id }).FirstOrDefault();

                if (query != null)
                {
                    idErrorMessage.Text = @"Inserimento rifiutato - I valori: Validità Da, Validità A, MacroArea, " +
                                      @"Rivenditore e Cliente sono in conflitto con la scheda ID = " + query.id.ToString();
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        protected bool ControlloIndice()
        {
            // Controllo violazione indice univoco su Schede_Intestazione
            long lidIntestazione = Convert.ToInt32(idNumScheda.Text);
            idErrorMessage.Text = "";
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                long lid_Cliente = Convert.ToInt32(id_Cliente.Text);
                var query = (from S in context.Schede_Intestazione
                             where S.Validita_Da_Mese == txtValidita_Da.Text &&
                                   S.Validita_A_Mese == txtValidita_A.Text &&
                                   S.Codice_MacroArea == ddlMacroArea.SelectedValue &&
                                   S.Rivenditore_KN == lblKNRivenditore.Text &&
                                   S.Cliente == lid_Cliente
                             select new { S.id }).FirstOrDefault();

                if (query != null)
                {
                    idErrorMessage.Text = @"Inserimento rifiutato - I valori: Validità Da, Validità A, MacroArea, " +
                                      @"Rivenditore e Cliente sono in conflitto con la scheda ID = " + query.id.ToString();
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        protected void btnSalvaScheda_Click(object sender, EventArgs e)
        {
            //int idIntestazione = Convert.ToInt32((Session["idScheda"]));
            long idIntestazione = Convert.ToInt32(idNumScheda.Text);
            if (ControlloScheda())
            {
                if (ControlloDate())
                {
                    if (ControlloIndicePerModifica())
                    {
                        using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                        {
                            using (var dbContextTransaction = context.Database.BeginTransaction())
                            {
                                try
                                {

                                    var intestazione = context.Schede_Intestazione.FirstOrDefault(S => S.id == idIntestazione);

                                    intestazione.Codice_MacroArea = ddlMacroArea.SelectedValue;
                                    intestazione.id_modello = Convert.ToInt32(id_modello.Text);
                                    intestazione.Codice_MacroArea = lblMCRivenditore.Text;
                                    intestazione.Agente1_Gid = lblGid_Agente_1.Text;
                                    intestazione.Agente2_Gid = lblGid_Agente_2.Text;
                                    if (lblGid_Agente_2.Text == "")
                                        intestazione.Agente2_Gid = null; // la FK dell'agente 2 è nullable
                                    else
                                        intestazione.Agente2_Gid = lblGid_Agente_2.Text;
                                    intestazione.Responsabile_Gid = lblGid_Responsabile.Text;
                                    intestazione.Validita_Da_Mese = txtValidita_Da.Text;
                                    intestazione.Validita_A_Mese = txtValidita_A.Text;
                                    intestazione.Cliente = Convert.ToInt32(id_Cliente.Text);
                                    intestazione.Rivenditore_KN = lblKNRivenditore.Text;
                                    intestazione.Filiale = lblFiliale.Text;
                                    intestazione.flag_IA = false;
                                    intestazione.flag_DT = false;
                                    intestazione.Codice_Cliente = txtCodice_Cliente.Text;
                                    intestazione.Rappresentante_Riv = txtRappresentante_Riv.Text;
                                    intestazione.Responsabile_Fil_Riv = txtResponsabile_Fil_Riv.Text;
                                    //intestazione.Firma_Resp_Fil_Riv = txtFirma_Resp_Fil_Riv.Text;
                                    intestazione.Firma_Resp_Fil_Riv = "";

                                    var buttonId = ((Button)sender).ID;
                                    switch (buttonId)
                                    {
                                        case "btnSalvaInBozza":
                                            intestazione.stato = "B";
                                            break;
                                        case "btnInviaPerApprovazione":
                                            intestazione.stato = "I";
                                            intestazione.Inviata_il = DateTime.Today;
                                            break;
                                        case "btnApprova":
                                            intestazione.stato = "A";
                                            intestazione.Approvata_il = DateTime.Today;
                                            break;
                                        case "btnRifiuta":
                                            intestazione.stato = "I";
                                            break;
                                    }
                                    intestazione.Modificata_il = DateTime.Today;
                                    context.SaveChanges();

                                    foreach (GridViewRow GVDettaglioRow in GVDettaglio.Rows)
                                    {
                                        Label lblDescProd = (Label)GVDettaglioRow.FindControl("lblIDescrizione_Prodotto");
                                        Label lblIFam_SC = (Label)GVDettaglioRow.FindControl("lblIFam_SC");
                                        if (lblDescProd.Text != "Raggruppamento")
                                        {

                                            var dettaglio = context.Schede_Dettaglio.First(D => D.id_Intestazione == idIntestazione &&
                                                                                                D.Codice_Famiglia_Sconti == lblIFam_SC.Text);


                                            TextBox txtSconto = (TextBox)GVDettaglioRow.FindControl("txtSconto");
                                            if (string.IsNullOrEmpty(txtSconto.Text))
                                                dettaglio.Sconto = 0;
                                            else
                                                dettaglio.Sconto = Convert.ToDecimal(txtSconto.Text);

                                            TextBox txtExtra = (TextBox)GVDettaglioRow.FindControl("txtExtra");
                                            if (string.IsNullOrEmpty(txtExtra.Text))
                                                dettaglio.Extra = 0;
                                            else
                                                dettaglio.Extra = Convert.ToDecimal(txtExtra.Text);

                                            TextBox txtRicarica = (TextBox)GVDettaglioRow.FindControl("txtRicarica");
                                            if (txtRicarica == null || string.IsNullOrEmpty(txtRicarica.Text))
                                                dettaglio.Ricarica = 0;
                                            else
                                                dettaglio.Ricarica = Convert.ToDecimal(txtRicarica.Text);

                                            context.SaveChanges();
                                        }
                                    }

                                    // Cancella Prezzi Netti e li inserisce di nuovo
                                    var prezzi_netti_old = context.Prezzi_Netti.Where(P => P.id_Intestazione == idIntestazione).ToList();

                                    foreach (var P in prezzi_netti_old)
                                    {
                                        context.Prezzi_Netti.Remove(P);
                                    }

                                    context.SaveChanges();

                                    GVPrezziNetti.AllowPaging = false;
                                    BindPrezziNetti();
                                    foreach (GridViewRow GVPrezziNettiRow in GVPrezziNetti.Rows)
                                    {
                                        Prezzi_Netti prezzi_netti = new Prezzi_Netti();

                                        prezzi_netti.id_Intestazione = intestazione.id;
                                        prezzi_netti.Codice_Materiale = GVPrezziNettiRow.Cells[0].Text;
                                        prezzi_netti.Prezzo_Netto = Convert.ToDecimal(GVPrezziNettiRow.Cells[1].Text);
                                        prezzi_netti.Ricarica = Convert.ToDecimal(GVPrezziNettiRow.Cells[2].Text);

                                        context.Prezzi_Netti.Add(prezzi_netti);

                                    }

                                    context.SaveChanges();

                                    dbContextTransaction.Commit();

                                    switch (intestazione.stato)
                                    {
                                        case "B":
                                            ut.InsLog(SIEMENS_GID, "Modifica", intestazione.id, "INFO", "Stato: BOZZA");
                                            break;
                                        case "I":
                                            ut.InsLog(SIEMENS_GID, "Modifica", intestazione.id, "INFO", "Stato: INVIO PER APPROVAZIONE");
                                            break;
                                        case "A":
                                            ut.InsLog(SIEMENS_GID, "Modifica", intestazione.id, "INFO", "Stato: APPROVATA");
                                            break;
                                    }

                                    Response.Redirect("MainSchede.aspx", false);
                                }
                                catch (System.Exception ex)
                                {
                                    dbContextTransaction.Rollback();
                                    ut.InsLog(SIEMENS_GID, "Modifica", idIntestazione, "ERRORE", ex.ToString());
                                    MessageBox(@"Si è verificato un errore durante la modifica della scheda " + idIntestazione.ToString() +
                                               ". Consultare il log.", "Errore aggiornamento scheda");
                                }
                            }
                        }
                    }
                }
            }
        }

        // Questa funzione è uguale all'inserimento della scheda, ogni modifica va riportata anche in
        // btnSalvaScheda_Click() in InsSchede.aspx.cs
        protected void btnCopiaScheda_Click(object sender, EventArgs e)
        {
            if (ControlloScheda())
            {
                if (ControlloDate())
                {
                    if (ControlloIndice())
                    {
                        using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                        {
                            using (var dbContextTransaction = context.Database.BeginTransaction())
                            {
                                try
                                {
                                    Schede_Intestazione intestazione = new Schede_Intestazione();
                                    intestazione.id_modello = Convert.ToInt32(id_modello.Text);
                                    intestazione.Codice_MacroArea = ddlMacroArea.SelectedValue;
                                    intestazione.Agente1_Gid = lblGid_Agente_1.Text;
                                    if (lblGid_Agente_2.Text == "")
                                        intestazione.Agente2_Gid = null; // la FK dell'agente 2 è nullable
                                    else
                                        intestazione.Agente2_Gid = lblGid_Agente_2.Text;
                                    intestazione.Responsabile_Gid = lblGid_Responsabile.Text;
                                    intestazione.Validita_Da_Mese = txtValidita_Da.Text;
                                    intestazione.Validita_A_Mese = txtValidita_A.Text;
                                    intestazione.Cliente = Convert.ToInt32(id_Cliente.Text);
                                    intestazione.Rivenditore_KN = lblKNRivenditore.Text;
                                    intestazione.Filiale = lblFiliale.Text;
                                    intestazione.flag_IA = false;
                                    intestazione.flag_DT = false;
                                    intestazione.Creata_il = DateTime.Today;

                                    intestazione.stato = "B";

                                    intestazione.Codice_Cliente = txtCodice_Cliente.Text;
                                    intestazione.Rappresentante_Riv = txtRappresentante_Riv.Text;
                                    intestazione.Responsabile_Fil_Riv = txtResponsabile_Fil_Riv.Text;
                                    intestazione.Firma_Resp_Fil_Riv = "";
                                    //intestazione.Firma_Resp_Fil_Riv = txtFirma_Resp_Fil_Riv.Text;

                                    context.Schede_Intestazione.Add(intestazione);

                                    context.SaveChanges(); //Salvo prima l'intestazione per ottenere l'id

                                    lidSchedaErrore = intestazione.id;

                                    foreach (GridViewRow GVDettaglioRow in GVDettaglio.Rows)
                                    {
                                        Label lblDescProd = (Label)GVDettaglioRow.FindControl("lblIDescrizione_Prodotto");
                                        if (lblDescProd.Text != "Raggruppamento")
                                        {
                                            Schede_Dettaglio dettaglio = new Schede_Dettaglio();

                                            dettaglio.id_Intestazione = intestazione.id;

                                            Label lblIFam_SC = (Label)GVDettaglioRow.FindControl("lblIFam_SC");
                                            dettaglio.Codice_Famiglia_Sconti = lblIFam_SC.Text;

                                            TextBox txtSconto = (TextBox)GVDettaglioRow.FindControl("txtSconto");
                                            if (string.IsNullOrEmpty(txtSconto.Text))
                                                dettaglio.Sconto = 0;
                                            else
                                                dettaglio.Sconto = Convert.ToDecimal(txtSconto.Text);

                                            TextBox txtExtra = (TextBox)GVDettaglioRow.FindControl("txtExtra");
                                            if (string.IsNullOrEmpty(txtExtra.Text))
                                                dettaglio.Extra = 0;
                                            else
                                                dettaglio.Extra = Convert.ToDecimal(txtExtra.Text);

                                            TextBox txtRicarica = (TextBox)GVDettaglioRow.FindControl("txtRicarica");
                                            //if (txtRicarica == null && string.IsNullOrEmpty(txtRicarica.Text))
                                            if (txtRicarica == null)
                                                dettaglio.Ricarica = 0;
                                            else
                                                dettaglio.Ricarica = Convert.ToDecimal(txtRicarica.Text);

                                            context.Schede_Dettaglio.Add(dettaglio);
                                        }
                                    }

                                    GVPrezziNetti.AllowPaging = false;
                                    BindPrezziNetti();
                                    foreach (GridViewRow GVPrezziNettiRow in GVPrezziNetti.Rows)
                                    {
                                        Prezzi_Netti prezzi_netti = new Prezzi_Netti();

                                        prezzi_netti.id_Intestazione = intestazione.id;
                                        prezzi_netti.Codice_Materiale = GVPrezziNettiRow.Cells[0].Text;
                                        prezzi_netti.Prezzo_Netto = Convert.ToDecimal(GVPrezziNettiRow.Cells[1].Text);
                                        prezzi_netti.Ricarica = Convert.ToDecimal(GVPrezziNettiRow.Cells[2].Text);

                                        context.Prezzi_Netti.Add(prezzi_netti);
                                    }

                                    context.SaveChanges();

                                    dbContextTransaction.Commit();

                                    ut.InsLog(SIEMENS_GID, "Copia", intestazione.id, "INFO", "Scheda copiata da " + idNumScheda.Text);

                                    Session["idUltimaSchedaInserita"] = intestazione.id.ToString();
                                    Response.Redirect("MainSchede.aspx", false);
                                }
                                catch (System.Exception ex)
                                {
                                    dbContextTransaction.Rollback();
                                    ut.InsLog(SIEMENS_GID, "Copia", lidSchedaErrore, "ERRORE", ex.ToString());
                                    MessageBox("Si è verificato un errore durante la copia della scheda " + lidSchedaErrore.ToString() +
                                               ". Consultare il log.", "Errore copia scheda");
                                }
                            }
                        }
                    }
                }
            }
        }
        protected void btnSearchModello_Click(object sender, EventArgs e)
        {

        }
        protected void btnRimuoviScheda_Click(object sender, EventArgs e)
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {

                long idscheda = Convert.ToInt32(idNumScheda.Text);
                var intestazione = context.Schede_Intestazione.FirstOrDefault(S => S.id == idscheda);
                context.Schede_Intestazione.Remove(intestazione);
                context.SaveChanges();

                ut.InsLog(SIEMENS_GID, "Modifica", intestazione.id, "INFO", "Scheda Rimossa dall'archivio");

                Response.Redirect("MainSchede.aspx", false);

            }
        }
        protected void btnImportInDettaglio_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[4] { new DataColumn("Fam_SC", typeof(string)),
                                new DataColumn("Sconto", typeof(float)),
                                new DataColumn("Extra", typeof(float)),
                                new DataColumn("Ricarica",typeof(float)) });

            dt.PrimaryKey = new DataColumn[] { dt.Columns["Fam_SC"] };

            string CopiedDettaglio = txtCopiedDettaglio.Text;
            if (CopiedDettaglio != null)
            {
                foreach (string row in CopiedDettaglio.Split('\n'))
                {
                    if (!string.IsNullOrEmpty(row))
                    {
                        int i = 0;
                        DataRow dr = dt.NewRow();
                        foreach (string cell in row.Split('\t'))
                        {
                            dr[i++] = cell;
                        }
                        dt.Rows.Add(dr);
                    }
                }
            }

            foreach (GridViewRow GVDettaglioRow in GVDettaglio.Rows)
            {
                Label lblDescProd = (Label)GVDettaglioRow.FindControl("lblIDescrizione_Prodotto");
                if (lblDescProd.Text != "Raggruppamento")
                {

                    Label lblIFam_SC = (Label)GVDettaglioRow.FindControl("lblIFam_SC");
                    string strFind = lblIFam_SC.Text;
                    DataRow foundRow = dt.Rows.Find(strFind);

                    if (foundRow != null)
                    {
                        TextBox txtSconto = (TextBox)GVDettaglioRow.FindControl("txtSconto");
                        txtSconto.Text = foundRow[1].ToString();
                        TextBox txtExtra = (TextBox)GVDettaglioRow.FindControl("txtExtra");
                        txtExtra.Text = foundRow[2].ToString();
                        Label lblSC_Finale = (Label)GVDettaglioRow.FindControl("lblSC_Finale");
                        lblSC_Finale.Text = (Decimal.Round(Convert.ToDecimal(txtSconto.Text) + ((1 - (Convert.ToDecimal(txtSconto.Text) / 100)) * Convert.ToDecimal(txtExtra.Text)), 2)).ToString();
                        HiddenField hidSC_Finale = (HiddenField)GVDettaglioRow.FindControl("hidSC_Finale");
                        hidSC_Finale.Value = lblSC_Finale.Text;
                        TextBox txtRicarica = (TextBox)GVDettaglioRow.FindControl("txtRicarica");
                        if (txtRicarica != null)
                            txtRicarica.Text = foundRow[3].ToString();
                    }
                }
            }
        }
        protected void btnExportFromDettaglio_Click(object sender, EventArgs e)
        {

        }

        protected void btnCaricaDettaglioDaTesto_Click(object sender, EventArgs e)
        {
            ModalPopupDettaglioDaTesto.Show();
        }
        private void MessageBox(string message, string title = "title")
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), title, "alert('" + message + "');", true);
        }

        //protected void btnCancelAgenti_2_Click(object sender, EventArgs e)
        //{
        //    lblGid_Agente_2.Text = "";
        //    lblAgente2.Text = "";
        //}
    }
}