﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class ModScontoRivCli : System.Web.UI.Page
    {
        private static string SIEMENS_GID = "";
        private Utilities ut = new Utilities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SIEMENS_GID = (string)Session["SIEMENS_GID"];
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    // Macro aree di competenza
                    ddlMacroArea.DataSource = context.GetMacroaree(SIEMENS_GID).ToList();
                    ddlMacroArea.DataBind();

                    // Prende l'ultimo modello
                    var qryUltimoModello = context.Modelli_Intestazione 
                        .Select(M => new { M.id, M.Validita_Da })
                        .OrderByDescending(M => M.Validita_Da)
                        .FirstOrDefault();
                    long id_modello = qryUltimoModello.id;

                    // Prende i codici famiglia sconto dall'ultimo modello
                    var qryModelliDettaglio = context.Modelli_Dettaglio
                        .Select(MD => new { MD.id_modello, MD.Codice_Famiglia_Sconti })
                        .Where(MD => MD.id_modello == id_modello);

                    // Seleziona solo il codice famiglia sconto
                    ddlfamigliaSconto.DataSource = qryModelliDettaglio.Select(FS => FS.Codice_Famiglia_Sconti).ToList();
                    ddlfamigliaSconto.DataBind();
                }
            }
        }

        // C L I E N T I ------------------------------------------------------
        protected void btnSearchClienti_Click(object sender, EventArgs e)
        {
            ViewState["Ragione_Sociale"] = "";
            BindClienti();
            ModalPopupClienti.Show();
        }
        void BindClienti()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                if (context.Clienti.Count() > 0)
                {
                    if ((string)ViewState["Ragione_Sociale"] == "")
                    {
                        GVClienti.DataSource = context.Clienti
                            .Where(C => C.Codice_MacroArea == ddlMacroArea.SelectedValue)
                            .OrderBy(C => C.Ragione_Sociale).ToList();
                    }
                    else
                    {
                        string strFilter = (string)ViewState["Ragione_Sociale"];
                        GVClienti.DataSource = context.Clienti
                            .Where(C => C.Codice_MacroArea == ddlMacroArea.SelectedValue && C.Ragione_Sociale.StartsWith(strFilter))
                            .OrderBy(C => C.Ragione_Sociale).ToList();
                    }
                    GVClienti.DataBind();
                }
            }
        }
        protected void GVClienti_SelectedIndexChanged(object sender, EventArgs e)
        {
            id_Cliente.Text = GVClienti.SelectedRow.Cells[1].Text;
            lblRagioneSociale.Text = ((Label)GVClienti.SelectedRow.FindControl("lblRagione_Sociale")).Text.ToString();
            //lblRagioneSociale.Text = GVClienti.SelectedRow.Cells[2].Text;
            lblP_Iva.Text = GVClienti.SelectedRow.Cells[3].Text;
            GVClienti.DataSource = null;
            GVClienti.DataBind();
        }
        protected void GVClienti_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVClienti.PageIndex = e.NewPageIndex;
            BindClienti();
            ModalPopupClienti.Show();
        }
        protected void GVClienti_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["Ragione_Sociale"] = ((TextBox)GVClienti.HeaderRow.FindControl("txtRagione_Sociale")).Text.ToString();
            BindClienti();
            ModalPopupClienti.Show();
        }
        protected void txtRagione_Sociale_TextChanged(object sender, EventArgs e)
        {
            ViewState["Ragione_Sociale"] = ((TextBox)GVClienti.HeaderRow.FindControl("txtRagione_Sociale")).Text.ToString();
            BindClienti();
            ModalPopupClienti.Show();
        }
        protected void GVClienti_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if ((string)ViewState["Ragione_Sociale"] != "")
                {
                    var txtRagione_Sociale = (TextBox)GVClienti.HeaderRow.FindControl("txtRagione_Sociale");
                    if (txtRagione_Sociale != null)
                        txtRagione_Sociale.Text = ViewState["Ragione_Sociale"].ToString();
                }
            }
        }

        // R I V E N D I T O R I ----------------------------------------------
        protected void btnSearchRivenditori_Click(object sender, EventArgs e)
        {
            ViewState["Ragione_Sociale_Riv"] = "";
            BindRivenditori();
            ModalPopupRivenditori.Show();
        }
        void BindRivenditori()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                if (context.Rivenditori.Count() > 0)
                {
                    if ((string)ViewState["Ragione_Sociale_Riv"] == "")
                    {
                        var qryRivenditori = from RM in context.RivenditoriMacroarea
                                             join R in context.Rivenditori on RM.KN equals R.KN
                                             where RM.Codice_MacroArea == ddlMacroArea.SelectedValue
                                             orderby R.Ragione_Sociale
                                             select new { R.Ragione_Sociale, RM.KN, RM.Codice_MacroArea, R.flg_Ricarica };
                        GVRivenditori.DataSource = qryRivenditori.ToList();
                    }
                    else
                    {
                        string strFilter = (string)ViewState["Ragione_Sociale_Riv"];
                        var qryRivenditori = from RM in context.RivenditoriMacroarea
                                             join R in context.Rivenditori on RM.KN equals R.KN
                                             where RM.Codice_MacroArea == ddlMacroArea.SelectedValue && R.Ragione_Sociale.StartsWith(strFilter)
                                             orderby R.Ragione_Sociale
                                             select new { R.Ragione_Sociale, RM.KN, RM.Codice_MacroArea, R.flg_Ricarica };
                        GVRivenditori.DataSource = qryRivenditori.ToList();
                    }
                    GVRivenditori.DataBind();
                }
            }
        }
        protected void GVRivenditori_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblRivenditore.Text = ((Label)GVRivenditori.SelectedRow.FindControl("lblRagione_Sociale_Riv")).Text.ToString();
            lblKNRivenditore.Text = GVRivenditori.SelectedRow.Cells[2].Text;
            GVRivenditori.DataSource = null;
            GVRivenditori.DataBind();
        }
        protected void GVRivenditori_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVRivenditori.PageIndex = e.NewPageIndex;
            BindRivenditori();
            ModalPopupRivenditori.Show();
        }
        protected void GVRivenditori_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["Ragione_Sociale_Riv"] = ((TextBox)GVRivenditori.HeaderRow.FindControl("txtRagione_Sociale_Riv")).Text.ToString();
            BindRivenditori();
            ModalPopupRivenditori.Show();
        }
        protected void txtRagione_Sociale_Riv_TextChanged(object sender, EventArgs e)
        {
            ViewState["Ragione_Sociale_Riv"] = ((TextBox)GVRivenditori.HeaderRow.FindControl("txtRagione_Sociale_Riv")).Text.ToString();
            BindRivenditori();
            ModalPopupRivenditori.Show();
        }
        protected void GVRivenditori_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if ((string)ViewState["Ragione_Sociale_Riv"] != "")
                {
                    var txtRagione_Sociale_Riv = (TextBox)GVRivenditori.HeaderRow.FindControl("txtRagione_Sociale_Riv");
                    if (txtRagione_Sociale_Riv != null)
                        txtRagione_Sociale_Riv.Text = ViewState["Ragione_Sociale_Riv"].ToString();
                }
            }
        }

        protected bool Controllo()
        {
            string strErrorMessage = "";
            idErrorMessage.Text = "";

            if (id_Cliente.Text == "")
                strErrorMessage = strErrorMessage + @"Identificativo Cliente; ";

            if (lblKNRivenditore.Text == "")
                strErrorMessage = strErrorMessage + @"Identificativo Rivenditore; ";

            if (txtSconto.Text == "")
                strErrorMessage = strErrorMessage + @"Sconto. ";

            if (strErrorMessage == "")
                return true;
            else
            {
                idErrorMessage.Text = "Risultano non inseriti i seguenti campi obbligatori: " + strErrorMessage;
                return false;
            }
        }
        protected void btnAggiorna_Click(object sender, EventArgs e)
        {
            if (Controllo())
            {
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    int? retModScontoRivCli = (context.ModScontoRivCli(SIEMENS_GID, 
                                                                    lblKNRivenditore.Text, 
                                                                    lblP_Iva.Text, 
                                                                    ddlfamigliaSconto.SelectedValue, 
                                                                    Convert.ToDecimal(txtSconto.Text))).FirstOrDefault();
                    idErrorMessage.Text = "Sono state aggiornate " + retModScontoRivCli.ToString() + " schede.";
                    if (retModScontoRivCli > 0)
                        idErrorMessage.Text = idErrorMessage.Text + " Controllare il log per un report dettagliato.";
                }
            }
        }
    }
}