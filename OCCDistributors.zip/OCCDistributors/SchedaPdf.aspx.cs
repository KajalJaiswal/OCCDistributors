﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.UI.HtmlControls;

namespace OCCDist
{
    public partial class SchedaPdf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BindData();
        }
        private void BindData()
        {
            using (OCCEntities context = new OCCEntities())
            {
                idNumScheda.Text = Request.QueryString["idscheda"];
                int idIntestazione = Convert.ToInt32(idNumScheda.Text);

                var intestazione = context.Schede_Intestazione.FirstOrDefault(S => S.id == idIntestazione);

                lblMacroArea.Text = intestazione.Codice_MacroArea;

                var modello = (from M in context.Modelli_Intestazione
                               where M.id == intestazione.id_modello
                               select new { M.Descrizione }).FirstOrDefault();

                lbl_Descr_Modello.Text = modello.Descrizione;

                var agente1 = (from A in context.Agenti
                               join U in context.Utenti on A.Gid equals U.GID
                               where A.Codice_MacroArea == intestazione.Codice_MacroArea && A.Gid == intestazione.Agente1_Gid
                               select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome }).FirstOrDefault();

                lblAgente1.Text = agente1.Cognome + " " + agente1.Nome;

                var agente2 = (from A in context.Agenti
                               join U in context.Utenti on A.Gid equals U.GID
                               where A.Codice_MacroArea == intestazione.Codice_MacroArea && A.Gid == intestazione.Agente2_Gid
                               select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome }).FirstOrDefault();


                if (agente2 != null)
                {
                    lblAgente2.Text = agente2.Cognome + " " + agente2.Nome;
                }

                var responsabile = (from R in context.Responsabili
                                    join U in context.Utenti on R.GID equals U.GID
                                    where R.Codice_MacroArea == intestazione.Codice_MacroArea && R.GID == intestazione.Responsabile_Gid
                                    select new { R.Codice_MacroArea, R.GID, U.Cognome, U.Nome }).FirstOrDefault();

                lblResponsabile.Text = responsabile.Cognome + " " + responsabile.Nome;
                lblValidita_Da.Text = intestazione.Validita_Da_Mese;
                lblValidita_A.Text = intestazione.Validita_A_Mese;

                var cliente = context.Clienti.FirstOrDefault(C => C.id == intestazione.Cliente);

                lblRagioneSociale.Text = cliente.Ragione_Sociale;
                lblP_Iva.Text = cliente.P_Iva;
                lblComune.Text = cliente.Comune;
                lblCAP.Text = cliente.CAP;
                lblProvincia.Text = cliente.Provincia;

                //var rivenditore = context.Rivenditori.FirstOrDefault(R => R.Codice_MacroArea == intestazione.Codice_MacroArea && R.KN == intestazione.Rivenditore_KN);
                var rivenditore = (from RM in context.RivenditoriMacroarea
                                   join R in context.Rivenditori on RM.KN equals R.KN
                                   where RM.Codice_MacroArea == intestazione.Codice_MacroArea && RM.KN == intestazione.Rivenditore_KN
                                   select new { R.Ragione_Sociale }).First();

                lblRivenditore.Text = rivenditore.Ragione_Sociale;

                lblFiliale.Text = intestazione.Filiale;

                //chkIA.Checked = intestazione.flag_IA;
                //chkDT.Checked = intestazione.flag_DT;
                lblCodice_Cliente.Text = intestazione.Codice_Cliente;
                lblRappresentante_Riv.Text = intestazione.Rappresentante_Riv;
                lblResponsabile_Fil_Riv.Text = intestazione.Responsabile_Fil_Riv;
                lblFirma_Resp_Fil_Riv.Text = intestazione.Firma_Resp_Fil_Riv;
                //ddlStatoScheda.SelectedValue = intestazione.stato;
                //idCreatail.Text = string.Format("{0:dd/MM/yyyy}", intestazione.Creata_il);
                //idInviatail.Text = string.Format("{0:dd/MM/yyyy}", intestazione.Inviata_il);
                //idApprovatail.Text = string.Format("{0:dd/MM/yyyy}", intestazione.Approvata_il);

                string sqlQuery = @"SELECT DISTINCT MRAG.DESCRIZIONE, MDET.CODICE_RAGGRUPPAMENTO,FSCO.DESCRIZIONE_SPIRIDON,FSCO.CATALOGO,FSCO.DESCRIZIONE_PRODOTTO, " +
                                    @"SDET.CODICE_FAMIGLIA_SCONTI  AS 'FAM_SC', CASE WHEN (FRIV.FAM_SC IS NULL) THEN '' END AS 'FAM_SC_RIV', SDET.SCONTO AS 'SCONTO', " +
                                    @"SDET.EXTRA AS 'EXTRA', ' ' AS 'SC_FINALE', SDET.RICARICA AS 'RICARICA', MRAG.POSIZIONE, MDET.POSIZIONE " +
                                    @"FROM SCHEDE_DETTAGLIO SDET  " +
                                    @"JOIN SCHEDE_INTESTAZIONE SINT  ON SDET.ID_INTESTAZIONE = SINT.ID  " +
                                    @"JOIN FAMIGLIA_SCONTI FSCO ON SDET.CODICE_FAMIGLIA_SCONTI = FSCO.CODICE  " +
                                    @"LEFT JOIN FAM_SC_RIVENDITORE FRIV ON FSCO.Codice = FRIV.Codice_Famiglia_Sconti_Siemens  " +
                                    @"JOIN MODELLI_DETTAGLIO MDET ON FSCO.CODICE = MDET.CODICE_FAMIGLIA_SCONTI  " +
                                    @"JOIN MODELLI_RAGGRUPPAMENTO MRAG ON MDET.CODICE_RAGGRUPPAMENTO = MRAG.CODICE " +
                                    @"JOIN MODELLI_INTESTAZIONE MINT ON MRAG.ID_MODELLO = MINT.ID " +
                                    @"WHERE SDET.ID_INTESTAZIONE = " + idIntestazione + @" AND MINT.ID = SINT.ID_MODELLO " +
                                    @"ORDER BY MRAG.POSIZIONE, MDET.POSIZIONE";

                var query = context.Database.SqlQuery<retDettaglio>(sqlQuery).ToList();

                var DTDettaglio = new DataTable();
                DTDettaglio.Columns.AddRange(new DataColumn[]{ 
                new DataColumn("Descrizione_raggruppamento" , typeof(string)),
                new DataColumn("Codice_raggruppamento" , typeof(string)),
                new DataColumn("Descrizione_Spiridon" , typeof(string)),
                new DataColumn("Catalogo" , typeof(string)),
                new DataColumn("Descrizione_Prodotto" , typeof(string)),
                new DataColumn("Fam_SC" , typeof(string)),
                new DataColumn("Fam_SC_Riv" , typeof(string)),
                new DataColumn("Sconto" , typeof(string)),
                new DataColumn("Extra" , typeof(string)),
                new DataColumn("Ricarica" , typeof(string)),
            });

                string tmpRaggruppamento = "";
                foreach (var item in query)
                {
                    DataRow dr = DTDettaglio.NewRow();
                    if (tmpRaggruppamento != item.Codice_raggruppamento)
                    {
                        DataRow drRag = DTDettaglio.NewRow();
                        drRag["Descrizione_raggruppamento"] = "";
                        drRag["Codice_raggruppamento"] = "";
                        drRag["Descrizione_Spiridon"] = item.Descrizione; //Descrizione Raggruppamento
                        drRag["Catalogo"] = "";
                        drRag["Descrizione_Prodotto"] = "Raggruppamento";
                        drRag["Fam_SC"] = item.Codice_raggruppamento;
                        drRag["Fam_SC_Riv"] = "";
                        drRag["Sconto"] = "";
                        drRag["Extra"] = "";
                        drRag["Ricarica"] = "";
                        DTDettaglio.Rows.Add(drRag);
                        tmpRaggruppamento = item.Codice_raggruppamento;
                    }
                    dr["Descrizione_raggruppamento"] = item.Descrizione;
                    dr["Codice_raggruppamento"] = item.Codice_raggruppamento;
                    dr["Descrizione_Spiridon"] = item.Descrizione_Spiridon;
                    dr["Catalogo"] = item.Catalogo;
                    if (item.Descrizione_Prodotto.Length > 50)
                        dr["Descrizione_Prodotto"] = item.Descrizione_Prodotto.Substring(0, 50);
                    else
                        dr["Descrizione_Prodotto"] = item.Descrizione_Prodotto;
                    dr["Fam_SC"] = item.Fam_SC;
                    dr["Fam_SC_Riv"] = item.Fam_SC_Riv;
                    dr["Sconto"] = item.Sconto;
                    dr["Extra"] = item.Extra;
                    dr["Ricarica"] = item.Ricarica;
                    DTDettaglio.Rows.Add(dr);
                }
                ViewState["dtDettaglio"] = DTDettaglio;
                GVDettaglio.DataSource = ViewState["dtDettaglio"] as DataTable;
                GVDettaglio.DataBind();
            }
        }

        protected void GVDettaglio_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                Label lblDescProd = (Label)e.Row.FindControl("lblIDescrizione_Prodotto");
                if (lblDescProd.Text == "Raggruppamento")
                {
                    Label lblIDescrizione_Spiridon = (Label)e.Row.FindControl("lblIDescrizione_Spiridon");
                    lblIDescrizione_Spiridon.BackColor = System.Drawing.Color.LightGray;
                    lblIDescrizione_Spiridon.ForeColor = System.Drawing.Color.Gray;
                    Label lblICatalogo = (Label)e.Row.FindControl("lblICatalogo");
                    lblICatalogo.BackColor = System.Drawing.Color.LightGray;
                    lblICatalogo.ForeColor = System.Drawing.Color.Gray;
                    lblDescProd.BackColor = System.Drawing.Color.LightGray;
                    lblDescProd.ForeColor = System.Drawing.Color.Gray;
                    Label lblFamSC = (Label)e.Row.FindControl("lblIFam_SC");
                    lblFamSC.BackColor = System.Drawing.Color.LightGray;
                    lblFamSC.ForeColor = System.Drawing.Color.Gray;
                    e.Row.Font.Bold = true;
                    e.Row.ForeColor = System.Drawing.Color.LightYellow;
                    e.Row.FindControl("lblIFam_SC_Riv").Visible = false;
                    e.Row.FindControl("txtSconto").Visible = false;
                    e.Row.FindControl("txtExtra").Visible = false;
                    e.Row.FindControl("lblSC_Finale").Visible = false;
                    e.Row.FindControl("txtRicarica").Visible = false;
                }
                else
                {
                    Label txtSconto = (Label)e.Row.FindControl("txtSconto");
                    Label txtExtra = (Label)e.Row.FindControl("txtExtra");
                    Label lblSC_Finale = (Label)e.Row.FindControl("lblSC_Finale");
                    if (Convert.ToInt32(txtSconto.Text) > 0)
                    {
                        lblSC_Finale.Text = (Convert.ToInt32(txtSconto.Text) + ((1 - (Convert.ToDouble(txtSconto.Text) / 100)) * Convert.ToInt32(txtExtra.Text))).ToString();
                    }
                }
            }
        }
    }
}