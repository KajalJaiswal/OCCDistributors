﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

namespace OCCDist
{
    public partial class SelUtente : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string Ambiente = ConfigurationManager.AppSettings["Ambiente"];
            
            // Da cancellare appena avrò i certificati per l'entitlement
            if (Request.QueryString["IhcsoF"] == "OniotnA")
            {
                Ambiente = "Prod";
                Session["AMMINISTRATORE"] = true;
            }
            
            if (Ambiente == "Prod" && (Boolean)Session["AMMINISTRATORE"] == false)
            {
                Response.Redirect("AccessDenied.aspx");
            }
            if (!IsPostBack)
            {
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    var qryUtenti = (from U in context.Utenti
                                     orderby U.Cognome
                                     select new {Username = U.Cognome + " " + U.Nome + " " + U.Tipo, U.GID}).ToList();

                    ddlSelUtente.DataSource = qryUtenti;
                    ddlSelUtente.DataValueField = "GID";
                    ddlSelUtente.DataTextField = "Username";
                    ddlSelUtente.DataBind();
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session.Add("SIEMENS_GID", ddlSelUtente.SelectedValue);
            string SIEMENS_GID = (string)Session["SIEMENS_GID"];
            Session.Add("AMMINISTRATORE", false);
            Session.Add("SEGRETERIA", false);
            Session.Add("RESPONSABILE", false);
            Session.Add("UTENTE", false);
            Session.Add("NOMINATIVO", "");
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                var qryTipoUtente = context.TipoUtente(SIEMENS_GID);
                foreach (var item in qryTipoUtente)
                {
                    switch (item)
                    {
                        case "Amministratore":
                            Session["AMMINISTRATORE"] = true;
                            break;
                        case "Segreteria":
                            Session["SEGRETERIA"] = true;
                            break;
                        case "Responsabile":
                            Session["RESPONSABILE"] = true;
                            break;
                        case "Utente":
                            Session["UTENTE"] = true;
                            var qryUtenti = (from U in context.Utenti
                                             where U.GID == SIEMENS_GID
                                             select U).FirstOrDefault();
                            Session.Add("NOMINATIVO", qryUtenti.Cognome + " " + qryUtenti.Nome);
                            break;
                    }
                }
            }
            Response.Redirect("Default.aspx");
        }
    }
}