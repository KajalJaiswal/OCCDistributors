﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
//using System.Windows.Forms;

namespace OCCDist
{
    public partial class TestClipboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void CaricaPrezziNetti()
        {
            using (OCCEntities context = new OCCEntities())
            {

                var prezzi_netti = context.Prezzi_Netti
                    .Where(I => I.id_Intestazione == 1225)
                    .OrderBy(I => I.Codice_Materiale).ToList();

                string strPrezziNetti = "";
                foreach (Prezzi_Netti item in prezzi_netti)
                {
                    strPrezziNetti = strPrezziNetti + item.Codice_Materiale + '\t';
                    strPrezziNetti = strPrezziNetti + item.Prezzo_Netto + '\t';
                    strPrezziNetti = strPrezziNetti + item.Ricarica + '\n';
                }
                ViewState["PrezziNetti"] = strPrezziNetti;
                BindPrezziNetti();

                idBadgePrezziNetti.InnerText = (prezzi_netti.Count).ToString();
            }
        }
        protected void btnVisualizzaPrezziNetti_Click(object sender, EventArgs e)
        {
            CaricaPrezziNetti();
            ModalPopupPrezziNetti.Show();
        }
        protected void BindPrezziNetti()
        {
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[3] { new DataColumn("Codice_Materiale", typeof(string)),
                    new DataColumn("Prezzo_Netto", typeof(float)),
                    new DataColumn("Ricarica",typeof(float)) });

            string strPrezziNetti = (string)ViewState["PrezziNetti"];
            foreach (string row in strPrezziNetti.Split('\n'))
            {
                if (!string.IsNullOrEmpty(row))
                {
                    dt.Rows.Add();
                    int i = 0;
                    foreach (string cell in row.Split('\t'))
                    {
                        dt.Rows[dt.Rows.Count - 1][i] = cell;
                        i++;
                    }
                }
            }
            GVPrezziNetti.DataSource = dt;
            GVPrezziNetti.DataBind();

            idBadgePrezziNetti.InnerText = (dt.Rows.Count).ToString();

        }
        protected void GVPrezziNetti_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVPrezziNetti.PageIndex = e.NewPageIndex;
            BindPrezziNetti();
            ModalPopupPrezziNetti.Show();
        }

        protected void btnDelGrid_Click(object sender, EventArgs e)
        {
            ViewState["PrezziNetti"] = "";
            BindPrezziNetti();
            ModalPopupPrezziNetti.Show();
        }
        protected void btnExportFromGrid_Click(object sender, EventArgs e)
        {
            txtCopied.Text = (string)ViewState["PrezziNetti"];
            ModalPopupPrezziNetti.Show();
        }
        protected void btnImportInGrid_Click(object sender, EventArgs e)
        {
            ViewState["PrezziNetti"] = txtCopied.Text;
            BindPrezziNetti();
            txtCopied.Text = "";
            ModalPopupPrezziNetti.Show();
        }


    }
}