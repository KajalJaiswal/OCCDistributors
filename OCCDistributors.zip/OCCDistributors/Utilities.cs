﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace OCCDist
{
    public class Utilities
    {
        public bool GidCanReadScheda(string SIEMENS_GID, string idScheda)
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                //select dbo.CanRead('XP003WES', 18)
                long lidScheda = Convert.ToInt32(idScheda);
                string sqlQuery = @"select dbo.CanRead('" + SIEMENS_GID + "', " + lidScheda + ")";

                var query = context.Database.SqlQuery<bool>(sqlQuery).FirstOrDefault();

                if (query)
                    return true;
                else
                    return false;
            }
        }
        public bool GidCanWriteScheda(string SIEMENS_GID, string idScheda)
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                //select dbo.CanRead('XP003WES', 18)
                long lidScheda = Convert.ToInt32(idScheda);
                string sqlQuery = @"select dbo.CanWrite('" + SIEMENS_GID + "', " + lidScheda + ")";

                var query = context.Database.SqlQuery<bool>(sqlQuery).FirstOrDefault();

                if (query)
                    return true;
                else
                    return false;
            }
        }

        public bool InsLog(string SIEMENS_GID, string Funzione, long idScheda, string Tipo, string Messaggio)
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                var query = context.InsLog(SIEMENS_GID, Funzione, idScheda, Tipo, Messaggio);
            }
            return true;
        }
    }
}