﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OCCDist
{
    public class retMainSchede
    {
        public long id { get; set; }
        public long id_modello { get; set; }
        public string Codice_MacroArea { get; set; }
        public string stato { get; set; }
        public string Agente1_Gid { get; set; }
        public string Agente2_Gid { get; set; }
        public string Responsabile_Gid { get; set; }
        public string Validita_Da_Mese { get; set; }
        public string Validita_A_Mese { get; set; }
        public string GID { get; set; }
        public string U1_Cognome { get; set; }
        public string U1_Nome { get; set; }
        public string U2_Cognome { get; set; }
        public string U2_Nome { get; set; }
        public string UR_Cognome { get; set; }
        public string UR_Nome { get; set; }
        public string Riv_RagioneSociale { get; set; }
        public string Cli_RagioneSociale { get; set; }

    }
}