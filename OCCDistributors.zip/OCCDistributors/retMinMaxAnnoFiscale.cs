﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OCCDist
{
    public class retMinMaxAnnoFiscale
    {
        public string Min_Periodo_Mese { get; set; }
        public string Max_Periodo_Mese { get; set; }
    }
}